<!DOCTYPE html>
<html lang="en">

<head>
  <title>Travell - Stays</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Figtree:ital,wght@0,300..900;1,300..900&display=swap"
    rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <meta name="csrf-token" content="{{ csrf_token() }}">
  <script type="text/javascript" src="{{ asset('/public/frontend/hotel-detail/js/jquery.min.js')}}"></script>
  <script type="text/javascript" src="{{ asset('/public/frontend/hotel-detail/js/bootstrap.bundle.min.js')}}"></script>
  <script type="text/javascript" src="{{ asset('/public/frontend/hotel-detail/js/jquery-ui-datepicker.min.js')}}">
  </script>

  <link rel="stylesheet" href="{{ asset('/public/frontend/hotel-detail/css/bootstrap.min.css')}}">
  <link rel="stylesheet" href="{{ asset('/public/frontend/hotel-detail/css/style.css')}}">
  <link rel="stylesheet" href="{{ asset('/public/frontend/hotel-detail/css/calendar.css')}}" media="screen">
  <link rel="stylesheet" href="{{ asset('/public/frontend/hotel-detail/css/responsive.css')}}">
  <link rel="stylesheet" href="{{ asset('/public/css/custom.css')}}">
  <link rel="stylesheet" href="{{ asset('/public/frontend/hotel-detail/css/custom.css')}}">
</head>

<body>
  <!--HEADER-->
    @include('frontend.header_without_search')

  <!-- Mobile Navigation-->
  <div class="tr-mobile-nav-section">
    <div class="tr-mobile-nav-content">
      <button type="button" class="btn-nav-close" id=""></button>
      <div class="tr-nav-header">
        <div class="tr-logo">
          <img src="images/travell-small-logo.png" alt="travell small logo">
        </div>
        <div class="tr-location">London</div>
      </div>
      <div class="tr-mobile-nav-lists">
        <ul>
          <li><svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path
                d="M2.5 7.49984L10 1.6665L17.5 7.49984V16.6665C17.5 17.1085 17.3244 17.5325 17.0118 17.845C16.6993 18.1576 16.2754 18.3332 15.8333 18.3332H4.16667C3.72464 18.3332 3.30072 18.1576 2.98816 17.845C2.67559 17.5325 2.5 17.1085 2.5 16.6665V7.49984Z"
                stroke="#222222" stroke-linecap="round" stroke-linejoin="round" />
              <path d="M7.5 18.3333V10H12.5V18.3333" stroke="#222222" stroke-linecap="round" stroke-linejoin="round" />
            </svg>Explore</li>
          <li><svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path
                d="M2.5 7.49984L10 1.6665L17.5 7.49984V16.6665C17.5 17.1085 17.3244 17.5325 17.0118 17.845C16.6993 18.1576 16.2754 18.3332 15.8333 18.3332H4.16667C3.72464 18.3332 3.30072 18.1576 2.98816 17.845C2.67559 17.5325 2.5 17.1085 2.5 16.6665V7.49984Z"
                stroke="#222222" stroke-linecap="round" stroke-linejoin="round" />
              <path d="M7.5 18.3333V10H12.5V18.3333" stroke="#222222" stroke-linecap="round" stroke-linejoin="round" />
            </svg>Hotels</li>
          <li><svg width="18" height="17" viewBox="0 0 18 17" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path
                d="M11.6677 8.21686L11.4782 8.25293L11.4075 8.43241L8.58835 15.5894L7.6097 15.7757L8.3748 9.30726L8.4309 8.83302L7.96178 8.92232L3.5739 9.75759L3.37156 9.79611L3.30699 9.99171L2.47522 12.5116L1.87823 12.6253L1.98228 9.2217L1.98466 9.14395L1.95388 9.07252L0.606627 5.94522L1.20367 5.83157L2.90392 7.86957L3.03583 8.02769L3.23812 7.98919L7.626 7.15392L8.09517 7.0646L7.86869 6.64412L4.77982 0.909331L5.75841 0.723048L11.0099 6.34373L11.1416 6.48469L11.3311 6.44861L15.7902 5.59979C16.0247 5.55515 16.2673 5.60549 16.4647 5.73973L16.6615 5.45033L16.4647 5.73973C16.6621 5.87398 16.798 6.08113 16.8426 6.31561C16.8873 6.55009 16.8369 6.79271 16.7027 6.99007L16.9921 7.18692L16.7027 6.99007C16.5685 7.18744 16.3613 7.3234 16.1268 7.36803L11.6677 8.21686Z"
                stroke="black" stroke-width="0.7"></path>
            </svg>Flights</li>
          <li><svg width="20" height="17" viewBox="0 0 20 17" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path
                d="M17.0835 9.43359H14.8335M3.58349 9.43359H5.83349M17.4116 5.68359L15.9485 1.78191C15.7289 1.19645 15.1693 0.808594 14.544 0.808594H6.12299C5.49773 0.808594 4.93804 1.19645 4.7185 1.78191L3.25537 5.68359M17.4116 5.68359L17.6299 6.26568C17.7524 6.59225 18.0646 6.80859 18.4133 6.80859C18.9068 6.80859 19.293 7.23341 19.2463 7.72462L18.8335 12.0586M17.4116 5.68359H18.9585M3.25537 5.68359L3.03708 6.26568C2.91462 6.59225 2.60243 6.80859 2.25366 6.80859C1.76023 6.80859 1.37395 7.23341 1.42073 7.72462L1.83349 12.0586M3.25537 5.68359H1.70849M1.83349 12.0586L1.95418 13.3258C2.0275 14.0957 2.67408 14.6836 3.44742 14.6836H3.5835M1.83349 12.0586V12.0586C1.55735 12.0586 1.3335 12.2824 1.3335 12.5586V15.0586C1.3335 15.4728 1.66928 15.8086 2.0835 15.8086H2.8335C3.24771 15.8086 3.5835 15.4728 3.5835 15.0586V14.6836M3.5835 14.6836H17.0835M17.0835 14.6836H17.2196C17.9929 14.6836 18.6395 14.0957 18.7128 13.3258L18.8335 12.0586M17.0835 14.6836V15.0586C17.0835 15.4728 17.4193 15.8086 17.8335 15.8086H18.5835C18.9977 15.8086 19.3335 15.4728 19.3335 15.0586V12.5586C19.3335 12.2825 19.1096 12.0586 18.8335 12.0586V12.0586M6.24161 3.33425L5.41255 5.82142C5.25067 6.30707 5.61214 6.80859 6.12406 6.80859H14.5429C15.0548 6.80859 15.4163 6.30707 15.2544 5.82142L14.4254 3.33425C14.2212 2.72174 13.648 2.68359 13.0024 2.68359H7.66463C7.01899 2.68359 6.44578 2.72174 6.24161 3.33425Z"
                stroke="black" stroke-width="0.7" stroke-linecap="round" stroke-linejoin="round"></path>
            </svg>Cars</li>
        </ul>
      </div>
      <div class="tr-mobile-nav-lists">
        <ul>
          <li><svg width="20" height="21" viewBox="0 0 20 21" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path
                d="M16.6719 6.14307H3.33854C2.41807 6.14307 1.67188 6.88926 1.67188 7.80973V16.1431C1.67188 17.0635 2.41807 17.8097 3.33854 17.8097H16.6719C17.5923 17.8097 18.3385 17.0635 18.3385 16.1431V7.80973C18.3385 6.88926 17.5923 6.14307 16.6719 6.14307Z"
                stroke="#222222" stroke-linecap="round" stroke-linejoin="round"></path>
              <path
                d="M13.3385 17.8091V4.47575C13.3385 4.03372 13.1629 3.6098 12.8504 3.29724C12.5378 2.98468 12.1139 2.80908 11.6719 2.80908H8.33854C7.89651 2.80908 7.47259 2.98468 7.16003 3.29724C6.84747 3.6098 6.67188 4.03372 6.67188 4.47575V17.8091"
                stroke="#222222" stroke-linecap="round" stroke-linejoin="round"></path>
            </svg>Write a review</li>
          <li><svg width="20" height="21" viewBox="0 0 20 21" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path
                d="M16.6719 6.14307H3.33854C2.41807 6.14307 1.67188 6.88926 1.67188 7.80973V16.1431C1.67188 17.0635 2.41807 17.8097 3.33854 17.8097H16.6719C17.5923 17.8097 18.3385 17.0635 18.3385 16.1431V7.80973C18.3385 6.88926 17.5923 6.14307 16.6719 6.14307Z"
                stroke="#222222" stroke-linecap="round" stroke-linejoin="round"></path>
              <path
                d="M13.3385 17.8091V4.47575C13.3385 4.03372 13.1629 3.6098 12.8504 3.29724C12.5378 2.98468 12.1139 2.80908 11.6719 2.80908H8.33854C7.89651 2.80908 7.47259 2.98468 7.16003 3.29724C6.84747 3.6098 6.67188 4.03372 6.67188 4.47575V17.8091"
                stroke="#222222" stroke-linecap="round" stroke-linejoin="round"></path>
            </svg>Trips</li>
        </ul>
      </div>
      <div class="tr-mobile-nav-lists">
        <h4>Company</h4>
        <ul>
          <li><a href="javascript:void(0);">About us</a></li>
          <li><a href="javascript:void(0);">Contact us</a></li>
          <li><a href="javascript:void(0);">Traveller’s Choice</a></li>
          <li><a href="javascript:void(0);">Travel stories</a></li>
          <li><a href="javascript:void(0);">Help</a></li>
        </ul>
      </div>
      <div class="tr-actions">
        <button class="tr-btn tr-write-review">Sign up / Log in</button>
      </div>
    </div>
  </div>
  <div class="tr-listing-without-dates-2">
  <div class="container">
    <div class="row">
      <div class="col-sm-12 ">
        <div class="tr-heading-section">
          <h1>Stay somewhere Great</h1>
          <h2>Compare prices from 70+ Hotels websites in just a single click</h2>
        </div>

        <!--HOTEL SEARCHES FORM- START-->
        <div class="tr-search-hotel">
          <form class="tr-hotel-form" id="hotelForm3">
            <div class="tr-form-section">
              <div class="tr-date-section"> 
              <input type="text" class="tr-room-guest" placeholder="1 room, 2 guests" id="totalRoomAndGuest" value="" name="" readonly="">  
              <div class="tr-add-edit-guest-count">
                      <div class="tr-guests-modal">
                        <div class="tr-add-edit-guest tr-total-num-of-rooms">
                          <div class="tr-guest-type">
                            <label class="tr-guest">Room</label>
                          </div>
                          <div class="tr-qty-box">
                            <button class="minus disabled" value="minus">-</button>
                            <input type="text" id="totalRoom" value="0" min="1" max="10" name="" readonly="">
                            <button class="plus" value="plus">+</button>
                          </div>
                        </div>
                        <div class="tr-add-edit-guest tr-total-guest">
                          <div class="tr-guest-type">
                            <label class="tr-guest">Adults</label>
                            <div class="tr-age">Ages 13 or above</div>
                          </div>
                          <div class="tr-qty-box">
                            <button class="minus disabled" value="minus">-</button>
                            <input type="text" id="totalAdultsGuest" value="0" min="1" max="10" name="" readonly="">
                            <button class="plus" value="plus">+</button>
                          </div>
                        </div>
                        <div class="tr-add-edit-guest tr-total-children">
                          <div class="tr-guest-type">
                            <label class="tr-guest">Children</label>
                            <div class="tr-age">Ages 2 - 12</div>
                          </div>
                          <div class="tr-qty-box">
                            <button class="minus disabled" value="minus">-</button>
                            <input type="text" id="totalChildrenGuest" value="0" min="1" max="10" name="" readonly="">
                            <button class="plus" value="plus">+</button>
                          </div>
                        </div>
                        <div class="tr-add-edit-guest tr-total-infants">
                          <div class="tr-guest-type">
                            <label class="tr-guest">Infants</label>
                            <div class="tr-age">Under 2</div>
                          </div>
                          <div class="tr-qty-box">
                            <button class="minus disabled" value="minus">-</button>
                            <input type="text" id="totalChildrenInfants" value="0" min="1" max="10" name="" readonly="">
                            <button class="plus" value="plus">+</button>
                          </div>
                        </div>
                      </div>
                    </div>
              </div>
              <div class="tr-form-fields">
                <div class="col tr-mobile">
                  <div class="tr-mobile-where">
                    <label class="tr-lable">Where to?</label>
                    <div class="tr-location-label">Search destinations</div>
                  </div>
                </div>
                <div class="col tr-mobile">
                  <div class="tr-mobile-when">
                    <label class="tr-lable">When</label>
                    <div class="tr-add-dates">Add dates</div>
                  </div>
                </div>
                <div class="col tr-form-where">
                  <div class="tr-mobile tr-close-btn">Where are you going?</div>
                  <label for="searchDestinations">Where</label>

                  <input id="searchDestinations" type="hidden" tabindex="1" placeholder="&#xF002; Search"
                    autocomplete="off">
                  <input type="text" class="form-control fffffff" id="searchhotel" placeholder="Search Location" value="" name=""
                    autocomplete="off">

                  <div class="" id="recentSearchsDestination">
                    <p id="hotel_loc_list" class="autoCompletewrapper tr-recent-searchs-modal"></p>
                  </div>
                  <span id="slug" class="d-none"></span>
                  <span id="hotel" class="d-none"></span>
                  <span id="location_id" class="d-none"></span>

                  <div class="tr-form-btn tr-mobile">
                    <button type="button" class="tr-btn">Countinue</button>
                  </div>
                </div>
                <?php date_default_timezone_set('Asia/Kolkata'); 
											
                      $checkinDate = date('Y-m-d', strtotime(' +1 day'));  
                      $checkoutDate = date('Y-m-d', strtotime(' +4 day'));  
                      ?>
                <div class="col tr-form-booking-date">
                  <div class="tr-form-checkin">
                    <label for="checkInInput3">Check in</label>
                    <input type="text" value="{{ $checkinDate}}" class="form-control checkIn t-input-check-in"
                      id="checkInInput3" placeholder="Add dates" name="" autocomplete="off" readonly>
                  </div>
                  <div class="tr-form-checkout">
                    <label for="checkOutInput3">Check out</label>
                    <input type="text" value="{{ $checkoutDate}}" class="form-control checkOut t-input-check-out"
                      id="checkOutInput3" placeholder="Add dates" name="checkOut" autocomplete="off" readonly>
                  </div>
                  <div class="tr-calenders-modal" id="calendarsModal3" style="display: none">
                    <div id="calendarPair3" class="calendarPair">
                      <div class="navigation">
                        <button type="button" class="prevMonth" id="prevMonth3">Previous</button>
                        <button type="button" class="nextMonth" id="nextMonth3">Next</button>
                      </div>
                      <div class="custom-calendar checkInCalendar" id="checkInCalendar3">
                        <div class="monthYear"></div>
                        <div class="calendarBody"></div>
                      </div>
                      <div class="custom-calendar checkOutCalendar" id="checkOutCalendar3">
                        <div class="monthYear"></div>
                        <div class="calendarBody"></div>
                      </div>
                      <button type="button" class="tr-clear-details" hidden id="reset3">Clear dates</button>
                    </div>
                  </div>
                  <div class="col tr-form-btn">
                    <button type="button" class="tr-btn tr-mobile">Next</button>
                  </div>
                </div>
                <div class="col tr-form-who">
                  <label for="totalRoomAndGuest">Who</label>
                  <input type="text" class="form-control tr-total-room-and-guest" id="totalRoomAndGuest3"
                    placeholder="Add guests" name="" autocomplete="off" readonly>
                  <div class="tr-guests-modal" id="guestQtyModal">
                    <div class="tr-add-edit-guest tr-total-num-of-rooms">
                      <div class="tr-guest-type">
                        <label class="tr-guest">Room</label>
                      </div>
                      <div class="tr-qty-box">
                        <button class="minus disabled" value="minus">-</button>
                        <input type="text" id="totalRoom" value="0" id="" min="1" max="10" name="" readonly />
                        <button class="plus" value="plus">+</button>
                      </div>
                    </div>
                    <div class="tr-add-edit-guest tr-total-guest">
                      <div class="tr-guest-type">
                        <label class="tr-guest">Adults</label>
                        <div class="tr-age">Ages 13 or above</div>
                      </div>
                      <div class="tr-qty-box">
                        <button class="minus disabled" value="minus">-</button>
                        <input type="text" id="totalAdultsGuest" value="0" id="" min="1" max="10" name="" readonly />
                        <button class="plus" value="plus">+</button>
                      </div>
                    </div>
                    <div class="tr-add-edit-guest tr-total-children">
                      <div class="tr-guest-type">
                        <label class="tr-guest">Children</label>
                        <div class="tr-age">Ages 2 - 12</div>
                      </div>
                      <div class="tr-qty-box">
                        <button class="minus disabled" value="minus">-</button>
                        <input type="text" id="totalChildrenGuest" value="0" id="" min="1" max="10" name="" readonly />
                        <button class="plus" value="plus">+</button>
                      </div>
                    </div>
                    <div class="tr-add-edit-guest tr-total-infants">
                      <div class="tr-guest-type">
                        <label class="tr-guest">Infants</label>
                        <div class="tr-age">Under 2</div>
                      </div>
                      <div class="tr-qty-box">
                        <button class="minus disabled" value="minus">-</button>
                        <input type="text" id="totalChildrenInfants" value="0" id="" min="1" max="10" name=""
                          readonly />
                        <button class="plus" value="plus">+</button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col tr-form-btn">
                <button class="tr-btn tr-popup-btn filter-chackinouts" id=""><span class="tr-desktop">Get
                    Price</span><span class="tr-mobile">Search</span></button>
              </div>
            </div>
          </form>
        </div>
        <!--HOTEL SEARCHES FORM- START-->

        <!--RECENT SEARCHES - START-->
          @if(session('recent_searches'))
        <div class="tr-recent-searches-hotel-section">
          <h3>Recent searches</h3>
          <div class="tr-recent-searches-hotel-listing">
            <div class="tr-recent-searches-hotel-lists">
              @if(session('recent_searches'))
              @foreach(session('recent_searches') as $search)
              <?php
                // Format check-in and check-out dates
                $checkinFormatted = date('d-M-Y', strtotime($search['checkin']));
                $checkoutFormatted = date('d-M-Y', strtotime($search['checkout']));
                
                // Construct the URL
                 $url = url('ho-' .$search['slug']) . 
                            '?checkin=' . $checkinFormatted .
                '&checkout=' . $checkoutFormatted .
                '&locationid=' . $search['locationid'] .
                '&lid=' .
                '&rooms=' . $search['rooms'] .
                '&guest=' . $search['guest'];

            ?>
         
              <div class="tr-recent-searches-hotel-list">
                <a href="{{ $url }}">
                  <div class="tr-city-name">{{ $search['fullname'] }}</div>
                  <div class="tr-booking-dates">
                    <?php
                              // Format check-in date
                              $checkinDate = new DateTime($search['checkin']);
                              $checkinFormatted = $checkinDate->format('D, d M');
                              
                              // Format check-out date
                              $checkoutDate = new DateTime($search['checkout']);
                              $checkoutFormatted = $checkoutDate->format('D, d M');
                          ?>
                    {{ $checkinFormatted }} - {{ $checkoutFormatted }}
                  </div>
                </a>
              </div>
              @endforeach

              @endif

            </div>
          </div>
        </div>
       @endif
        <!--RECENT SEARCHES - END-->

        <!--PARTNERS - START-->
        <div class="tr-partners-section">
          <div class="tr-partners-title">70+ Partners :</div>
          <div class="tr-partners-lists">
            <div class="tr-partners-list">
              <img src="{{ asset('public/frontend/hotel-detail/images/booking.png')}}" alt="Booking" />
            </div>
            <div class="tr-partners-list">
              <img src="{{ asset('public/frontend/hotel-detail/images/expedia.png')}}" alt="expedia" />
            </div>
            <div class="tr-partners-list">
              <img src="{{ asset('public/frontend/hotel-detail/images/agoda.png')}}" alt="agoda" />
            </div>
            <div class="tr-partners-list">
              <img src="{{ asset('public/frontend/hotel-detail/images/trip.png')}}" alt="trip" />
            </div>
          </div>
        </div>
        <!--PARTNERS - END-->

        <!--More Places - START-->
        <div class="tr-more-places responsive-container">
          <h3 class="d-none d-md-block">You might like these</h3>
          <h3 class="d-block d-sm-block d-md-none">Top hotels</h3>
          <div class="tr-sub-title d-none d-md-block">More places to stay</div>
          <div class="row tr-more-places-lists filter-listing">
          @forelse($searchresults as $searchresult)
          <div class="tr-more-places-list">
            <div class="tr-hotel-img">
              <a href="javascript:void(0):">
                @if ($searchresult->image == 1)
                <img src="https://s3-us-west-2.amazonaws.com/s3-travell/hotel-images/{{$searchresult->id}}.jpg" alt=""
                  style="width: 100%; height: auto; border-radius: 10px;">
                @else
                <img src="https://photo.hotellook.com/image_v2/crop/h{{ $searchresult->hotelid }}_1/580/443.jpg"
                  alt="{{$searchresult->name}}" style="width: 100%; height: auto; border-radius: 10px;">
                @endif
              </a>
            </div>
            <div class="tr-hotel-deatils">
              <div class="tr-hotel-city">City of {{$searchresult->cityName}}</div>
              <div class="tr-hotel-name">
                <a href="{{ url('hd-'.$searchresult->slugid.'-' .$searchresult->id .'-'.strtolower( str_replace(' ', '_',  str_replace('#', '!',$searchresult->slug) )) ) }}" target="_blank" title="{{$searchresult->name}}">{{$searchresult->name}}</a>
              </div>
              <div class="tr-hotel-facilities">
                <ul>                   
                  @if($searchresult->distance !="") <li>{{$searchresult->distance}}  miles to city </li>@endif 
                </ul>
                <ul>
                  @if(!empty($amenities))
                  @foreach(explode(',', $amenities) as $amenity)
                  <li>{{ trim($amenity) }}</li>
                  @endforeach
                  @endif
                  @if(!empty($room_aminities))
                  @foreach(explode(',', $room_aminities) as $roommnt)
                  <li>{{ trim($roommnt) }}</li>
                  @endforeach
                  @endif
                </ul>
              </div>
              <div class="tr-likes">
                <span class="tr-heart">
                  <svg width="12" height="11" viewBox="0 0 12 11" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path fill-rule="evenodd" clip-rule="evenodd"
                      d="M5.99604 2.28959C5.02968 1.20745 3.41823 0.916356 2.20745 1.90727C0.996677 2.89818 0.826217 4.55494 1.77704 5.7269L5.99604 9.63412L10.215 5.7269C11.1659 4.55494 11.0162 2.88776 9.78463 1.90727C8.55304 0.92678 6.96239 1.20745 5.99604 2.28959Z"
                      fill="white" stroke="white" stroke-linecap="round" stroke-linejoin="round" />
                  </svg>
                </span>89%
              </div>
            </div>
          </div>
          @endforeach
          </div>
        </div>
        <!--More Places - END-->

        <!--City Wise Hotel and Price - START-->   
        <span class="locids d-none">{{$locationIds}}</span>
        <div class="tr-city-wise-hotels-section">
          <h3>Search for places to stay by destination</h3>
          <div class="tr-sub-title">Find Accommodation</div>
          <div class="getdata"></div>
        </div>
        <!--City Wise Hotel and Price - END-->   
       
        <!--TOP TIPS FOR FINDING LONDON HOTEL DEALS - START-->
        <div class="col-sm-12">
          <div class="tr-tips-finding-hotel">
            <h3>Here are some fun hotel trivia facts for you</h3>
            <ul>
              <li>World’s Oldest Hotel: The Nishiyama Onsen Keiunkan in Japan is the world’s oldest hotel, dating back to 705 AD. It’s been operated by the same family for over 50 generations!</li>
              <li>Underwater Rooms: The Manta Resort in Zanzibar offers an underwater room where guests can sleep surrounded by ocean life, 4 meters below the surface.</li>
              <li>Ice Hotels: Sweden’s ICEHOTEL, built every winter from ice and snow, melts away each spring. It’s completely rebuilt with new designs every year.</li>
              <li>The Most Expensive Suite: The Royal Penthouse Suite at the Hotel President Wilson in Geneva, Switzerland, costs around $80,000 per night. It includes 12 bedrooms, panoramic views of Lake Geneva, and a private staff.</li>
              <li>Larger Than Life: The First World Hotel in Malaysia holds the Guinness World Record for the largest hotel, with over 7,000 rooms!</li>
              <li>Floating Hotels: There are several floating hotels around the world, such as the Sunborn Yacht Hotel in London, which offers luxury accommodation aboard a superyacht.</li>
              <li>Treehouse Hotels: You can stay in treehouses in unique places like the Treehotel in Sweden, where rooms are suspended in the treetops with views of the forest and sky.</li>
              <li>Hogwarts-Like Hotel: The Georgian House Hotel in London offers Harry Potter-themed rooms, allowing guests to feel like they’re staying at Hogwarts.</li>
              <li>Room with a View: At the Burj Al Arab in Dubai, a sail-shaped luxury hotel, guests can take in views of the Arabian Gulf from their room – some of which even come with their own butlers!</li>
  			      <li>Themed Rooms: In Tokyo, Japan, the Hotel Gracery Shinjuku has a Godzilla-themed room, complete with a giant Godzilla statue peering into your window!</li>
            </ul>
          </div>
        </div>
        <!--TOP TIPS FOR FINDING LONDON HOTEL DEALS - END-->

		    <!--BREADCRUMB - START-->
        <div class="tr-breadcrumb-section">
          <ul class="tr-breadcrumb">
            <li><a href="{{route('homepage')}}">Home</a></li>             
            <li>Stays</li>
          </ul>
        </div>
        <!--BREADCRUMB - END-->

        <!--FAQS - START-->
        <!--
        <div class="tr-faqs-section">
          <h3 class="d-none d-md-block">FAQ’s</h3>
          <h3 class="d-block d-sm-block d-md-none">FAQ’s</h3>
          <div class="tr-faqs-ques-ans">
            <div class="tr-faqs-ques">Which facilities are available in the hotel?</div>
            <div class="tr-faqs-ans">Let’s embody your beautiful ideas together, simplify the way you visualize your
              next big things.</div>
          </div>
          <div class="tr-faqs-ques-ans">
            <div class="tr-faqs-ques">Is there a parking facility at the Arlington House Apartments?</div>
            <div class="tr-faqs-ans">Yes, the 5 star property, Arlington House Apartments provides parking facilities.
            </div>
          </div>
          <div class="tr-faqs-ques-ans">
            <div class="tr-faqs-ques">Can more than two adults stay in one room?</div>
            <div class="tr-faqs-ans">Yes, two adults can stay in single room.</div>
          </div>
          <div class="tr-faqs-ques-ans">
            <div class="tr-faqs-ques">Try using our Will my credit card be charged when I book my reservation?</div>
            <div class="tr-faqs-ans">Let’s embody your beautiful ideas together.</div>
          </div>
          <div class="tr-faqs-ques-ans">
            <div class="tr-faqs-ques">How will I get my money back after cancelling a hotel booking?</div>
            <div class="tr-faqs-ans">You will receive an automatic refund within 24 hrs.</div>
          </div>
        </div>
        -->
        <!--FAQS - END-->
      </div>
    </div>
	    
  </div>
	
   </div>

  <!--FOOTER-->
  @include('frontend.footer') 
  <div class="overlay" id="overLay"></div>
</body>

</html>

<script src="{{asset('public/frontend/hotel-detail/js/jquery.min.js')}}"></script>
<script type="text/javascript" src="{{ asset('/public/frontend/hotel-detail/js/common.js')}} "></script>

<script src="{{ asset('/public/js/custom.js')}}"></script>
<script src="{{ asset('/public/js/stays.js')}}"></script>