@foreach($sightreviews as $review)
<div class="tr-customer-review">
  <div class="tr-customer-details">
    <div class="tr-customer-detail">
      <img loading="lazy" src="{{asset('public/frontend/hotel-detail/images/customer.png')}}" alt="customer">
      <div class="tr-customer-name">
        <div>{{$review->Name}}</div>
        <div
          class="tr-recommended-title @if($review->IsRecommend == 1) tr-heart-green @elseif($review->IsRecommend == 0) tr-heart-red @endif">
          Recommended
          <!-- <span class="tr-time">(1 week ago)</span> -->
        </div>
      </div>
      <div class="tr-hotel-place">London</div>
    </div>
    <div class="tr-report">
      <div class="tr-report-icon"></div>
      <div class="tr-report-popup">
        <h5>Report this</h5>
        <div class="tr-follow">Follow</div>
      </div>
    </div>
  </div>
  <p>{{$review->ReviewDescription}}</p>
  <div class="tr-helpful">
    Was this helpful?
    <button class="tr-like-button">Like</button>
    <button class="tr-dislike-button">Dislike</button>
  </div>
</div>
@endforeach