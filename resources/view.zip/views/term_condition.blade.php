<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Terms and Conditions for Travell</title>

    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="{{ asset('/favicon.ico') }}">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">

    <!-- FontAwesome -->
    <script src="https://kit.fontawesome.com/b73881b7c2.js" crossorigin="anonymous"></script>

    <!-- Slick Carousel CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.min.css" rel="stylesheet" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick-theme.css" rel="stylesheet" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/slick-lightbox/0.2.12/slick-lightbox.css" rel="stylesheet" />

    <!-- Datepicker CSS -->
    <link href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" rel="stylesheet" />

    <!-- Custom CSS -->
    <link rel="stylesheet" href="{{ asset('/public/css/style.css') }}">
    <link rel="stylesheet" href="{{ asset('/public/css/custom.css') }}">
    <link rel="stylesheet" href="{{ asset('/public/frontend/hotel-detail/css/bootstrap.min.css')}}">
    <link rel="stylesheet" href="{{ asset('/public/frontend/hotel-detail/css/style.css')}}">
    <link rel="stylesheet" href="{{ asset('/public/frontend/hotel-detail/css/calendar.css')}}" media="screen">
    <link rel="stylesheet" href="{{ asset('/public/frontend/hotel-detail/css/responsive.css')}}">

    <!-- Additional Hotel Styles -->
    <link href="{{ asset('/public/css/hotel-css/autoComplete.min.css') }}" rel="stylesheet">
    <link href="{{ asset('/public/css/hotel-css/t-datepicker.min.css') }}" rel="stylesheet" type="text/css">

    <style>
        /* Custom styles applied only to the main content, excluding navbar */
        .main-content h2,
        .main-content h4  {
            font-size: 26px;
            margin-top: 40px;
            margin-bottom: 20px;
            font-weight: bold;
            color: #000000;
            text-align: left;
        }


        .main-content p,{
            font-size: 20px;
            margin-top: 20px;
            margin-bottom: 20px;
            line-height: 1.9;
            color: #000000;
        }

        .main-content ul {
    margin-top: 20px;
    margin-bottom: 20px;
    list-style-type: disc;
    margin-left: 20px;
    color: #000000;
}

.main-content li {
    list-style-position: inside;
    padding-left: 0;
    text-indent: -1.5em;
    font-size: 1.1em;
    margin: 0; /* Remove margin to eliminate space between bullet points */
    line-height: 1.6;
}

.main-content li:before {
    content: '• ';
    margin-left: 0;
}
    </style>

</head>

<body>

    <!-- Include Navbar -->
    @include('Loc_nav.loc_navbar')

    <!-- Main Content starts here -->
    <div class="main-content">
        <!-- Banner Section -->
        <div class="banner-container other-sections">
            <div class="container">
                <img src="{{ asset('public/images/homepagebanner.png') }}" class="img-fluid d-none d-md-block w-100" alt="Banner">
                <img src="{{ asset('public/images/bannermobile.png') }}" class="img-fluid d-md-none w-100" alt="Mobile Banner">
                <div class="banner-text">
                    Discover New <br> Destinations
                </div>
            </div>
        </div>

        <!-- Main Content -->
        <div class="container">
            <div class="row justify-content-between mt-md-94px">
                <div class="col-md-12">
                    <div class="fs-32 mb-16"><b>Terms and Conditions</b></div>
                    <p class="mt-1">Welcome to Travell! These Terms and Conditions govern your use of our website, located at <a href="https://www.travell.co/">www.travell.co</a>, and our services. By accessing or using our website, you agree to comply with and be bound by the following terms. Please read them carefully.</p>

                    <h2>1. Use of the Services</h2>
                    <p>Travell is an online platform that provides travel-related information and links to third-party services such as accommodation, flights, car rentals, and tours. We act solely as affiliates for third-party suppliers and do not sell any products or services directly. By using our services, you agree to be bound by these Terms and Conditions.</p>
                    <h4>You agree to:</h4>
                    <ul>
                        <li>Use the Site for personal, non-commercial purposes only.</li>
                        <li>Provide accurate and up-to-date information when submitting any details on the Site.</li>
                        <li>Not use any robot, spider, scraper, or other automated means to access the Site for any purpose.</li>
                    </ul>

                    <h2>2. Affiliate Relationships and Third-Party Links</h2>
                    <p>Travell provides links to third-party websites where users can book travel services. These links are affiliate links, meaning we may receive a commission for purchases made through them. However, Travell does not own or operate these third-party services and is not responsible for the content, availability, or quality of services provided by third parties.</p>

                    <h2>3. Prohibited Activities</h2>
                    <h4>When using the Site, you agree not to:</h4>
                    <ul>
                        <li>Engage in any unlawful, fraudulent, or abusive activity.</li>
                        <li>Violate any applicable local, national, or international laws or regulations.</li>
                        <li>Use the Site to distribute unsolicited advertisements or spam.</li>
                        <li>Reproduce, distribute, or modify any content from the Site without prior written permission from Travell.</li>
                    </ul>

                    <h2>4. Content and Intellectual Property</h2>
                    <p>All content on the Site, including text, images, graphics, and logos, is the property of Travell or its affiliates and is protected by intellectual property laws. You may not copy, distribute, or create derivative works based on the content without prior written consent.</p>

                    <h2>5. Liability Disclaimer</h2>
                    <p>Travell does not guarantee the accuracy, completeness, or reliability of the information on the Site. The content provided is for informational purposes only and is subject to change at any time.</p>
                    <h4>You acknowledge that Travell is not responsible for any damages, losses, or liabilities arising from:</h4>
                    <ul>
                        <li>The use of third-party websites or services.</li>
                        <li>Errors or inaccuracies in the content provided on the Site.</li>
                        <li>Any issues or disputes that arise between you and third-party suppliers.</li>
                    </ul>

                    <h2>6. Booking with Third-Party Suppliers</h2>
                    <p>When you make bookings through third-party links on our Site, you agree to review and be bound by the supplier’s terms and conditions, privacy policy, and other applicable rules. Travell is not responsible for booking errors, cancellations, or changes to reservations made with third-party suppliers.</p>

                    <h2>7. Travel Responsibilities</h2>
                    <h4>When planning and booking travel, it is your responsibility to:</h4>
                    <ul>
                        <li>Ensure your travel documents (e.g., passport, visa) are in order.</li>
                        <li>Confirm the entry and exit requirements of the destination country.</li>
                        <li>Comply with health and safety regulations, including vaccinations and other medical advice.</li>
                    </ul>
                    <p>Travell is not liable for any travel disruptions, including denied entry, missed flights, or unplanned expenses.</p>

                    <h2>8. Indemnification</h2>
                    <p>You agree to indemnify and hold harmless Travell, its affiliates, and employees from any claims, liabilities, damages, or expenses arising out of your use of the Site, your violation of these terms, or your violation of any third-party rights.</p>

                    <h2>9. Modifications to Terms</h2>
                    <p>We may update these Terms and Conditions at any time, and any changes will be posted on this page with the updated date. By continuing to use the Site after modifications, you agree to the revised terms.</p>

                    <h2>10. Jurisdiction and Governing Law</h2>
                    <p>These Terms and Conditions are governed by the laws of Chandigarh, India. Any legal disputes will be subject to the exclusive jurisdiction of the courts of Chandigarh, India.</p>

                    <h2>11. Contact Information</h2>
                    <h4>For any questions or concerns regarding these Terms and Conditions, please contact us at:</h4>
                    <p>
                        Travell<br>
                        SCO. 10, Industrial Area Phase – 2, Chandigarh - 160002<br>
                        Email: <a href="mailto:travell@outlook.in">travell@outlook.in</a>
                    </p>
                </div>
            </div>
        </div>
    </div> <!-- End of main-content -->

    <!-- Include Footer -->
    @include('footer')

</body>

</html>

<!-- Scripts -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.js"></script>
<script src="{{ asset('/public/css/hotel-css/t-datepicker.min.js') }}"></script>
<script src="{{ asset('/public/js/datepicker-homepage.js') }}"></script>
<script src="{{ asset('/public/js/custom.js') }}"></script>
