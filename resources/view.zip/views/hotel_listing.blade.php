<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Google Tag Manager -->
  <script>
  (function(w, d, s, l, i) {
    w[l] = w[l] || [];
    w[l].push({
      'gtm.start': new Date().getTime(),
      event: 'gtm.js'
    });
    var f = d.getElementsByTagName(s)[0],
      j = d.createElement(s),
      dl = l != 'dataLayer' ? '&l=' + l : '';
    j.async = true;
    j.src =
      'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
    f.parentNode.insertBefore(j, f);
  })(window, document, 'script', 'dataLayer', 'GTM-PTHP3JH4');
  </script>
  <!-- End Google Tag Manager -->
  <meta name="csrf-token" content="{{ csrf_token() }}">
  <title>BEST Hotels in @if(!empty($countryname)){{$countryname}} , {{$lname}} @endif - Travell</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Figtree:ital,wght@0,300..900;1,300..900&display=swap"
    rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

  <script type="text/javascript" src="{{ asset('/public/frontend/hotel-detail/js/jquery.min.js')}}"></script>
  <script type="text/javascript" src="{{ asset('/public/frontend/hotel-detail/js/bootstrap.bundle.min.js')}}"></script>
  <script type="text/javascript" src="{{ asset('/public/frontend/hotel-detail/js/jquery-ui-datepicker.min.js')}}">
  </script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <link rel="stylesheet" href="{{ asset('/public/frontend/hotel-detail/css/bootstrap.min.css')}}">
  <link rel="stylesheet" href="{{ asset('/public/frontend/hotel-detail/css/style.css')}}">
  <link rel="stylesheet" href="{{ asset('/public/frontend/hotel-detail/css/calendar.css')}}" media="screen">
  <link rel="stylesheet" href="{{ asset('/public/frontend/hotel-detail/css/responsive.css')}}">
  <link rel="stylesheet" href="{{ asset('/public/frontend/hotel-detail/css/custom.css')}}">
  <!-- <link rel="stylesheet" href="{{ asset('/public/css/custom.css')}}"> -->

  <link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css" />
  <style>
    #map {
      height: 100%; /* Set a fixed height */
      width: 100%;
    }
  </style>
</head>
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-PTHP3JH4" height="0" width="0"
    style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->

<body>
  <!--HEADER-->
  @if($pagetype=="withoutdate")
  @include('frontend.header_without_search')
  <span class="d-none ptype">withoutdate</span>
  @else
  @include('frontend.header')
  <span class="d-none ptype">withdate</span>
  @endif


  <!-- Mobile Navigation-->
  <div class="tr-mobile-nav-section">
    <div class="tr-mobile-nav-content">
      <button type="button" class="btn-nav-close" id=""></button>
      <div class="tr-nav-header">
        <div class="tr-logo">
          <img src="{{asset('public/frontend/hotel-detail/images/travell-small-logo.png')}}" alt="travell small logo">
        </div>
        <div class="tr-location">London</div>
      </div>
      <div class="tr-mobile-nav-lists">
        <ul>
          <li><svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path
                d="M2.5 7.49984L10 1.6665L17.5 7.49984V16.6665C17.5 17.1085 17.3244 17.5325 17.0118 17.845C16.6993 18.1576 16.2754 18.3332 15.8333 18.3332H4.16667C3.72464 18.3332 3.30072 18.1576 2.98816 17.845C2.67559 17.5325 2.5 17.1085 2.5 16.6665V7.49984Z"
                stroke="#222222" stroke-linecap="round" stroke-linejoin="round" />
              <path d="M7.5 18.3333V10H12.5V18.3333" stroke="#222222" stroke-linecap="round" stroke-linejoin="round" />
            </svg>Explore</li>
          <li><svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path
                d="M2.5 7.49984L10 1.6665L17.5 7.49984V16.6665C17.5 17.1085 17.3244 17.5325 17.0118 17.845C16.6993 18.1576 16.2754 18.3332 15.8333 18.3332H4.16667C3.72464 18.3332 3.30072 18.1576 2.98816 17.845C2.67559 17.5325 2.5 17.1085 2.5 16.6665V7.49984Z"
                stroke="#222222" stroke-linecap="round" stroke-linejoin="round" />
              <path d="M7.5 18.3333V10H12.5V18.3333" stroke="#222222" stroke-linecap="round" stroke-linejoin="round" />
            </svg>Hotels</li>
          <li><svg width="18" height="17" viewBox="0 0 18 17" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path
                d="M11.6677 8.21686L11.4782 8.25293L11.4075 8.43241L8.58835 15.5894L7.6097 15.7757L8.3748 9.30726L8.4309 8.83302L7.96178 8.92232L3.5739 9.75759L3.37156 9.79611L3.30699 9.99171L2.47522 12.5116L1.87823 12.6253L1.98228 9.2217L1.98466 9.14395L1.95388 9.07252L0.606627 5.94522L1.20367 5.83157L2.90392 7.86957L3.03583 8.02769L3.23812 7.98919L7.626 7.15392L8.09517 7.0646L7.86869 6.64412L4.77982 0.909331L5.75841 0.723048L11.0099 6.34373L11.1416 6.48469L11.3311 6.44861L15.7902 5.59979C16.0247 5.55515 16.2673 5.60549 16.4647 5.73973L16.6615 5.45033L16.4647 5.73973C16.6621 5.87398 16.798 6.08113 16.8426 6.31561C16.8873 6.55009 16.8369 6.79271 16.7027 6.99007L16.9921 7.18692L16.7027 6.99007C16.5685 7.18744 16.3613 7.3234 16.1268 7.36803L11.6677 8.21686Z"
                stroke="black" stroke-width="0.7"></path>
            </svg>Flights</li>
          <li><svg width="20" height="17" viewBox="0 0 20 17" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path
                d="M17.0835 9.43359H14.8335M3.58349 9.43359H5.83349M17.4116 5.68359L15.9485 1.78191C15.7289 1.19645 15.1693 0.808594 14.544 0.808594H6.12299C5.49773 0.808594 4.93804 1.19645 4.7185 1.78191L3.25537 5.68359M17.4116 5.68359L17.6299 6.26568C17.7524 6.59225 18.0646 6.80859 18.4133 6.80859C18.9068 6.80859 19.293 7.23341 19.2463 7.72462L18.8335 12.0586M17.4116 5.68359H18.9585M3.25537 5.68359L3.03708 6.26568C2.91462 6.59225 2.60243 6.80859 2.25366 6.80859C1.76023 6.80859 1.37395 7.23341 1.42073 7.72462L1.83349 12.0586M3.25537 5.68359H1.70849M1.83349 12.0586L1.95418 13.3258C2.0275 14.0957 2.67408 14.6836 3.44742 14.6836H3.5835M1.83349 12.0586V12.0586C1.55735 12.0586 1.3335 12.2824 1.3335 12.5586V15.0586C1.3335 15.4728 1.66928 15.8086 2.0835 15.8086H2.8335C3.24771 15.8086 3.5835 15.4728 3.5835 15.0586V14.6836M3.5835 14.6836H17.0835M17.0835 14.6836H17.2196C17.9929 14.6836 18.6395 14.0957 18.7128 13.3258L18.8335 12.0586M17.0835 14.6836V15.0586C17.0835 15.4728 17.4193 15.8086 17.8335 15.8086H18.5835C18.9977 15.8086 19.3335 15.4728 19.3335 15.0586V12.5586C19.3335 12.2825 19.1096 12.0586 18.8335 12.0586V12.0586M6.24161 3.33425L5.41255 5.82142C5.25067 6.30707 5.61214 6.80859 6.12406 6.80859H14.5429C15.0548 6.80859 15.4163 6.30707 15.2544 5.82142L14.4254 3.33425C14.2212 2.72174 13.648 2.68359 13.0024 2.68359H7.66463C7.01899 2.68359 6.44578 2.72174 6.24161 3.33425Z"
                stroke="black" stroke-width="0.7" stroke-linecap="round" stroke-linejoin="round"></path>
            </svg>Cars</li>
        </ul>
      </div>
      <div class="tr-mobile-nav-lists">
        <ul>
          <li><svg width="20" height="21" viewBox="0 0 20 21" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path
                d="M16.6719 6.14307H3.33854C2.41807 6.14307 1.67188 6.88926 1.67188 7.80973V16.1431C1.67188 17.0635 2.41807 17.8097 3.33854 17.8097H16.6719C17.5923 17.8097 18.3385 17.0635 18.3385 16.1431V7.80973C18.3385 6.88926 17.5923 6.14307 16.6719 6.14307Z"
                stroke="#222222" stroke-linecap="round" stroke-linejoin="round"></path>
              <path
                d="M13.3385 17.8091V4.47575C13.3385 4.03372 13.1629 3.6098 12.8504 3.29724C12.5378 2.98468 12.1139 2.80908 11.6719 2.80908H8.33854C7.89651 2.80908 7.47259 2.98468 7.16003 3.29724C6.84747 3.6098 6.67188 4.03372 6.67188 4.47575V17.8091"
                stroke="#222222" stroke-linecap="round" stroke-linejoin="round"></path>
            </svg>Write a review</li>
          <li><svg width="20" height="21" viewBox="0 0 20 21" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path
                d="M16.6719 6.14307H3.33854C2.41807 6.14307 1.67188 6.88926 1.67188 7.80973V16.1431C1.67188 17.0635 2.41807 17.8097 3.33854 17.8097H16.6719C17.5923 17.8097 18.3385 17.0635 18.3385 16.1431V7.80973C18.3385 6.88926 17.5923 6.14307 16.6719 6.14307Z"
                stroke="#222222" stroke-linecap="round" stroke-linejoin="round"></path>
              <path
                d="M13.3385 17.8091V4.47575C13.3385 4.03372 13.1629 3.6098 12.8504 3.29724C12.5378 2.98468 12.1139 2.80908 11.6719 2.80908H8.33854C7.89651 2.80908 7.47259 2.98468 7.16003 3.29724C6.84747 3.6098 6.67188 4.03372 6.67188 4.47575V17.8091"
                stroke="#222222" stroke-linecap="round" stroke-linejoin="round"></path>
            </svg>Trips</li>
        </ul>
      </div>
      <div class="tr-mobile-nav-lists">
        <h4>Company</h4>
        <ul>
          <li><a href="javascript:void(0);">About us</a></li>
          <li><a href="javascript:void(0);">Contact us</a></li>
          <li><a href="javascript:void(0);">Traveller’s Choice</a></li>
          <li><a href="javascript:void(0);">Travel stories</a></li>
          <li><a href="javascript:void(0);">Help</a></li>
        </ul>
      </div>
      <div class="tr-actions">
        <button class="tr-btn tr-write-review">Sign up / Log in</button>
      </div>
    </div>
  </div>

  <div @if($pagetype=='withoutdate' ) class="tr-listing-without-dates-1" @else class="tr-listing-with-dates-1" @endif>
    <div class="container">
      <div class="row">
        <div class="col-sm-12">
          @if($pagetype=="withoutdate")
          <div class="tr-heading-section">
            <h1>Hotels in {{$lname}}</h1>
            <h2>Compare prices from 70+ Hotels websites in just a single click</h2>
          </div>
          <!--HOTEL SEARCHES FORM- START-->
          <div class="tr-search-hotel">
            <form class="tr-hotel-form" id="hotelForm3">
              <div class="tr-form-section">
                <div class="tr-date-section">
                  <input type="text" class="tr-room-guest" placeholder="1 room, 2 guests" id="totalRoomAndGuest"
                    value="" name="" readonly="">
                  <div class="tr-add-edit-guest-count">
                    <div class="tr-guests-modal">
                      <div class="tr-add-edit-guest tr-total-num-of-rooms">
                        <div class="tr-guest-type">
                          <label class="tr-guest">Room</label>
                        </div>
                        <div class="tr-qty-box">
                          <button class="minus disabled" value="minus">-</button>
                          <input type="text" id="totalRoom" value="0" min="1" max="10" name="" readonly="">
                          <button class="plus" value="plus">+</button>
                        </div>
                      </div>
                      <div class="tr-add-edit-guest tr-total-guest">
                        <div class="tr-guest-type">
                          <label class="tr-guest">Adults</label>
                          <div class="tr-age">Ages 13 or above</div>
                        </div>
                        <div class="tr-qty-box">
                          <button class="minus disabled" value="minus">-</button>
                          <input type="text" id="totalAdultsGuest" value="0" min="1" max="10" name="" readonly="">
                          <button class="plus" value="plus">+</button>
                        </div>
                      </div>
                      <div class="tr-add-edit-guest tr-total-children">
                        <div class="tr-guest-type">
                          <label class="tr-guest">Children</label>
                          <div class="tr-age">Ages 2 - 12</div>
                        </div>
                        <div class="tr-qty-box">
                          <button class="minus disabled" value="minus">-</button>
                          <input type="text" id="totalChildrenGuest" value="0" min="1" max="10" name="" readonly="">
                          <button class="plus" value="plus">+</button>
                        </div>
                      </div>
                      <div class="tr-add-edit-guest tr-total-infants">
                        <div class="tr-guest-type">
                          <label class="tr-guest">Infants</label>
                          <div class="tr-age">Under 2</div>
                        </div>
                        <div class="tr-qty-box">
                          <button class="minus disabled" value="minus">-</button>
                          <input type="text" id="totalChildrenInfants" value="0" min="1" max="10" name="" readonly="">
                          <button class="plus" value="plus">+</button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="tr-form-fields">
                  <div class="col tr-mobile">
                    <div class="tr-mobile-where">
                      <label class="tr-lable">Where to?</label>
                      <div class="tr-location-label">Search destinations</div>
                    </div>
                  </div>
                  <div class="col tr-mobile">
                    <div class="tr-mobile-when">
                      <label class="tr-lable">When</label>
                      <div class="tr-add-dates">Add dates</div>
                    </div>
                  </div>
                  <div class="col tr-form-where">
                    <div class="tr-mobile tr-close-btn">Where are you going?</div>
                    <label for="searchDestinations">Where</label>

                    <input id="searchDestinations" type="hidden" tabindex="1" placeholder="&#xF002; Search"
                      autocomplete="off">
                    <input type="text" class="form-control fffffff" id="searchhotel"  value="@if($lname !=''){{$lname}}@endif" placeholder="Search Location"
                      name="" autocomplete="off">

                    <div class="" id="recentSearchsDestination">
                      <p id="hotel_loc_list" class="autoCompletewrapper tr-recent-searchs-modal"></p>
                    </div>
                    <span id="slug" class="d-none">{{$slgid}}-{{$slugdata}}</span>
                    <span id="hotel" class="d-none">0</span>
                    <span id="location_id" class="d-none">{{$slgid}}</span>

                    <div class="tr-form-btn tr-mobile">
                      <button type="button" class="tr-btn">Countinue</button>
                    </div>
                  </div>
                  <?php date_default_timezone_set('Asia/Kolkata');

                      $checkinDate = date('Y-m-d', strtotime(' +1 day'));
                      $checkoutDate = date('Y-m-d', strtotime(' +4 day'));
                      ?>
                  <div class="col tr-form-booking-date">
                    <div class="tr-form-checkin">
                      <label for="checkInInput3">Check in</label>
                      <input type="text" value="{{ $checkinDate}}" class="form-control checkIn t-input-check-in"
                        id="checkInInput3" placeholder="Add dates" name="" autocomplete="off" readonly>
                    </div>
                    <div class="tr-form-checkout">
                      <label for="checkOutInput3">Check out</label>
                      <input type="text" value="{{ $checkoutDate}}" class="form-control checkOut t-input-check-out"
                        id="checkOutInput3" placeholder="Add dates" name="checkOut" autocomplete="off" readonly>
                    </div>
                    <div class="tr-calenders-modal" id="calendarsModal3" style="display: none">
                      <div id="calendarPair3" class="calendarPair">
                        <div class="navigation">
                          <button type="button" class="prevMonth" id="prevMonth3">Previous</button>
                          <button type="button" class="nextMonth" id="nextMonth3">Next</button>
                        </div>
                        <div class="custom-calendar checkInCalendar" id="checkInCalendar3">
                          <div class="monthYear"></div>
                          <div class="calendarBody"></div>
                        </div>
                        <div class="custom-calendar checkOutCalendar" id="checkOutCalendar3">
                          <div class="monthYear"></div>
                          <div class="calendarBody"></div>
                        </div>
                        <button type="button" class="tr-clear-details" hidden id="reset3">Clear dates</button>
                      </div>
                    </div>
                    <div class="col tr-form-btn">
                      <button type="button" class="tr-btn tr-mobile">Next</button>
                    </div>
                  </div>
                  <div class="col tr-form-who">
                    <label for="totalRoomAndGuest">Who</label>
                    <input type="text" class="form-control tr-total-room-and-guest" id="totalRoomAndGuest3"
                      placeholder="Add guests" name="" autocomplete="off" readonly>
                    <div class="tr-guests-modal" id="guestQtyModal">
                      <div class="tr-add-edit-guest tr-total-num-of-rooms">
                        <div class="tr-guest-type">
                          <label class="tr-guest">Room</label>
                        </div>
                        <div class="tr-qty-box">
                          <button class="minus disabled" value="minus">-</button>
                          <input type="text" id="totalRoom" value="0" id="" min="1" max="10" name="" readonly />
                          <button class="plus" value="plus">+</button>
                        </div>
                      </div>
                      <div class="tr-add-edit-guest tr-total-guest">
                        <div class="tr-guest-type">
                          <label class="tr-guest">Adults</label>
                          <div class="tr-age">Ages 13 or above</div>
                        </div>
                        <div class="tr-qty-box">
                          <button class="minus disabled" value="minus">-</button>
                          <input type="text" id="totalAdultsGuest" value="0" id="" min="1" max="10" name="" readonly />
                          <button class="plus" value="plus">+</button>
                        </div>
                      </div>
                      <div class="tr-add-edit-guest tr-total-children">
                        <div class="tr-guest-type">
                          <label class="tr-guest">Children</label>
                          <div class="tr-age">Ages 2 - 12</div>
                        </div>
                        <div class="tr-qty-box">
                          <button class="minus disabled" value="minus">-</button>
                          <input type="text" id="totalChildrenGuest" value="0" id="" min="1" max="10" name=""
                            readonly />
                          <button class="plus" value="plus">+</button>
                        </div>
                      </div>
                      <div class="tr-add-edit-guest tr-total-infants">
                        <div class="tr-guest-type">
                          <label class="tr-guest">Infants</label>
                          <div class="tr-age">Under 2</div>
                        </div>
                        <div class="tr-qty-box">
                          <button class="minus disabled" value="minus">-</button>
                          <input type="text" id="totalChildrenInfants" value="0" id="" min="1" max="10" name=""
                            readonly />
                          <button class="plus" value="plus">+</button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col tr-form-btn">
                  <button class="tr-btn tr-popup-btn filter-chackinouts" id=""><span class="tr-desktop">Get
                      Price</span><span class="tr-mobile">Search</span></button>
                </div>
              </div>
            </form>
          </div>
          <!--HOTEL SEARCHES FORM- START-->
          <!--PARTNERS - START-->
          <div class="tr-partners-section">
            <div class="tr-partners-title">70+ Partners :</div>
            <div class="tr-partners-lists">
              <div class="tr-partners-list">
                <img src="{{ asset('public/frontend/hotel-detail/images/booking.png')}}" alt="Booking" />
              </div>
              <div class="tr-partners-list">
                <img src="{{ asset('public/frontend/hotel-detail/images/expedia.png')}}" alt="expedia" />
              </div>
              <div class="tr-partners-list">
                <img src="{{ asset('public/frontend/hotel-detail/images/agoda.png')}}" alt="agoda" />
              </div>
              <div class="tr-partners-list">
                <img src="{{ asset('public/frontend/hotel-detail/images/trip.png')}}" alt="trip" />
              </div>
            </div>
          </div>
          <!--PARTNERS - end-->
          @endif
          @if($pagetype=="withdate")
          <?php            $chekin = request()->get('checkin');
                         $chkout = request()->get('checkout');


                          if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $chekin)) {
                              $checkin = $chekin;
                          } else {
                            $chekin =  str_replace('-',' ',$chekin);
                            $chekin = strtotime($chekin);
                            $checkin = date('Y-m-d', $chekin);


                          }


                          if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $chkout)) {
                              $checkout = $chkout;
                          } else {
                            $chkout =  str_replace('-',' ',$chkout);
                            $chkout = strtotime($chkout);
                            $checkout = date('Y-m-d', $chkout);
                          }
                          if(request('guest') == 0 || request('guest') ==" "){
                            $guest = 1;
                          }else{
                           $guest = request('guest');
                          }

                ?>

          <span id="withdate" class="d-none">withdate</span>
          <span id="Tplocid" class="d-none">{{$locationid}}</span>
          <span id="Cin" class="d-none">{{$checkin}}</span>
          <span id="Cout" class="d-none">{{$checkout}}</span>
          <span id="rooms" class="d-none">{{request('rooms')}}</span>
          <span id="guest" class="d-none">{{$guest}}</span>
          <span class="d-none Tid">{{$Tid}}</span>
          <span class="d-none slugid">{{$slgid}}</span>

          <span class="d-none lname" id="lname">{{$lname}}</span>
          <div class="tr-shortmap-and-shotby-section">
            <div class="tr-short-map">
              <img src="{{ asset('public/frontend/hotel-detail/images/icons/map-pin-filled-black-icon.svg')}}"
                alt="map-pin" />
              <button class="tr-btn" data-bs-toggle="modal" data-bs-target="#mapModal">Show on map</button>
            </div>
            <div class="tr-title-filter-section">
              <div class="tr-row">
                <h1 class="d-none d-md-block">{{$lname}}: <span class="hotel_count"></span></h1>
                <h1 class="d-block d-sm-block d-md-none">{{$lname}}: hotels &amp; places to stay</h1>
                <div class="tr-share-section">
                  <a href="javascript:void(0);" class="tr-share" data-bs-toggle="modal"
                    data-bs-target="#shareModal">Share</a>
                </div>
              </div>
              <div class="tr-row">
                <div class="tr-shotby">
                  <div class="custom-select">
                    <label>Sort by:</label>
                    <select class="hl-filter" id="sort_by">
                      <option value="">Relevance</option>
                      <option value="recommended">Recommended</option>
                      <option value="top-rated">Top-rated</option>
                      <option value="price_desc">Price: High to Low</option>
                      <option value="price_asc">Price: Low to High</option>
                    </select>
                  </div>
                </div>
                <div class="d-none d-md-block">
                  <div class="tr-filter-selected-section selected-data" data-section="1"></div>
                </div>
              </div>
            </div>
          </div>
          @endif
          <div class="tr-hotel-info-section">

            <!--Filter - START-->
            @if($pagetype=="withoutdate")
            <div class="tr-filters-section">
              <h4 class="tr-filter-label">Filter:</h4>
              <div class="tr-filter-lists">
                <h5>Search by</h5>
                <ul>
                  <li class="tr-filter-list"><a href="{{ url('ho-'.$slgid .'-fls2-'.$slugdata ) }}">2+ Star</a></li>
                  <li class="tr-filter-list"><a href="{{ url('ho-'.$slgid .'-fls3-'.$slugdata ) }}">3+ Star</a></li>
                  <li class="tr-filter-list"><a href="{{ url('ho-'.$slgid .'-fls4-'.$slugdata ) }}">4+ Star</a></li>
                  <li class="tr-filter-list"><a href="{{ url('ho-'.$slgid .'-fls5-'.$slugdata ) }}">5 Star</a></li>
                </ul>
              </div>
              <div class="tr-filter-lists">
                <h5>Search by review score</h5>
                <ul>
                  <li class="tr-filter-list"><a href="#">6+ Okay</a></li>
                  <li class="tr-filter-list"><a href="#">7+ Good</a></li>
                  <li class="tr-filter-list"><a href="#">8+ Great</a></li>
                  <li class="tr-filter-list"><a href="#">9+ Excellent</a></li>
                </ul>
              </div>
              <div class="tr-filter-lists">
                <h5>Search by price</h5>
                <ul>
                  <li class="tr-filter-list"><a href="#">$32 - $223</a></li>
                  <li class="tr-filter-list"><a href="#">$223 - $415</a></li>
                  <li class="tr-filter-list"><a href="#">$415 - $607</a></li>
                  <li class="tr-filter-list"><a href="#">$607 - $799</a></li>
                  <li class="tr-filter-list"><a href="#">$799+ per night</a></li>
                </ul>
              </div>
              <div class="tr-filter-lists">
                <h5>Search by freebies</h5>
                <ul>
                  <li class="tr-filter-list"><a href="#">Free cancellation</a></li>
                  <li class="tr-filter-list"><a href="#">Free breakfast</a></li>
                  <li class="tr-filter-list"><a href="{{ url('ho-'.$slgid .'-flmparking-'.$slugdata ) }}">Free
                      parking</a></li>
                  <li class="tr-filter-list"><a href="{{ url('ho-'.$slgid .'-flmwifi-'.$slugdata ) }}">Free internet</a>
                  </li>
                </ul>
              </div>
            </div>

            @else
            <div class="tr-filters-section" data-section="1">
              <h4 class="tr-filter-label d-none d-md-block">Filter by:</h4>
              <h4 class="tr-filter-label d-block d-sm-block d-md-none">Filters</h4>
              <div class="d-block d-sm-block d-md-none">
                <div class="tr-filter-selected-section selected-data" data-section="1"></div>
              </div>
              <div class="tr-filter-lists">
                <h5>Pricing</h5>
                <div class="tr-price-graph">
                  <div class="tr-price-graph-col" style="height: 45px;"></div>
                  <div class="tr-price-graph-col" style="height: 64px;"></div>
                  <div class="tr-price-graph-col" style="height: 64px;"></div>
                  <div class="tr-price-graph-col" style="height: 73px;"></div>
                  <div class="tr-price-graph-col" style="height: 84px;"></div>
                  <div class="tr-price-graph-col" style="height: 76px;"></div>
                  <div class="tr-price-graph-col" style="height: 87px;"></div>
                  <div class="tr-price-graph-col" style="height: 81px;"></div>
                </div>
                <div class="tr-price-range-section">
                  <div class="tr-price-slider">
                    <input type="range" min="0" max="1000" value="0" class="min-range" step="1">
                    <input type="range" min="0" max="5000" value="5000" class="max-range" step="1">
                  </div>
                  <div class="tr-title min-price-title ">$0</div>
                  <div class="tr-title max-price-title ">$5000</div>
                  <div class="tr-range-values">
                    <div class="min-price hl-filter">Min Price</div>
                    <span>-</span>
                    <div class="max-price hl-filter">Max Price</div>
                  </div>
                </div>
              </div>
              <div class="tr-filter-lists mnt">
                <h5>Facilities</h5>
                <ul>

                  <li class="tr-filter-list hl-filter"><label class="tr-check-box"><input type="checkbox" name="mnt"
                        id="" class="filter" value="Wi-Fi in public areas">Free Wi-Fi in public areas<span
                        class="checkmark"></span></label></li>
                  <li class="tr-filter-list hl-filter"><label class="tr-check-box"><input type="checkbox" name="smnt"
                        id="" class="filter" value="breakfast">Free Breakfast<span class="checkmark"></span></label>
                  </li>
                  <li class="tr-filter-list hl-filter"><label class="tr-check-box"><input type="checkbox" name="smnt"
                        id="" class="filter" value="freeWifi">Free Wifi<span class="checkmark"></span></label></li>

                  <li class="tr-filter-list hl-filter"><label class="tr-check-box"><input type="checkbox" name="mnt"
                        id="" class="filter" value="Parking">Parking<span class="checkmark"></span></label></li>
                  <li class="tr-filter-list hl-filter"><label class="tr-check-box"><input type="checkbox" name="mnt"
                        id="" class="filter" value="Gym">Gym<span class="checkmark"></span></label></li>
                  <!-- <li class="tr-filter-list"><label class="tr-check-box"><input type="checkbox" name="" id=""
                        class="filter" value="Streaming service (like Netflix)">Streaming service (like Netflix)<span
                        class="checkmark"></span></label></li> -->
                  <li class="tr-filter-list hl-filter"><label class="tr-check-box"><input type="checkbox" name="mnt"
                        id="" class="filter" value="Laundry service"> Laundry service<span
                        class="checkmark"></span></label></li>
                  <li class="tr-filter-list hl-filter"><label class="tr-check-box"><input type="checkbox" name="mnt"
                        id="" class="filter" value="Bar">Bar<span class="checkmark"></span></label></li>
                  <li class="tr-filter-list hl-filter"><label class="tr-check-box"><input type="checkbox" name="mnt"
                        id="" class="filter" value="Restaurant/cafe">Restaurant/cafe<span
                        class="checkmark"></span></label></li>
                </ul>
              </div>
              <div class="tr-filter-lists star-rating">
                <h5>Hotel class</h5>
                <ul>
                  <li class="tr-filter-list hl-filter"><label class="tr-check-box"><input type="checkbox" name="rating"
                        id="" class="filter" value="5">5 Star<span class="checkmark"></span></label></li>
                  <li class="tr-filter-list hl-filter"><label class="tr-check-box"><input type="checkbox" name="rating"
                        id="" class="filter" value="4">4 Star<span class="checkmark"></span></label></li>
                  <li class="tr-filter-list hl-filter"><label class="tr-check-box"><input type="checkbox" name="rating"
                        id="" class="filter" value="3">3 Star<span class="checkmark"></span></label></li>
                  <li class="tr-filter-list hl-filter"><label class="tr-check-box"><input type="checkbox" name="rating"
                        id="" class="filter" value="2">2 Star<span class="checkmark"></span></label></li>

                </ul>
              </div>
              @if(!$gethoteltype->isEmpty())
              <div class="tr-filter-lists hoteltype">
                <h5>Property types</h5>
                <ul>
                  @foreach($gethoteltype as $val)
                  <li class="tr-filter-list hl-filter"><label class="tr-check-box"><input type="checkbox"
                        name="hoteltypes" id="" class="filter" value="{{$val->hid}}">{{$val->type}}<span
                        class="checkmark"></span></label></li>
                  @endforeach
                </ul>
              </div>
              @endif


              <!--Neighbourhoods-->


              <div class="tr-filter-lists agencies" id="agencies">
                @if(!empty($agencyData))
                <h5>Booking Providers</h5>
                  <ul>
                      @foreach($agencyData as $agency)
                          <li class="tr-filter-list hl-filter">
                              <label class="tr-check-box">
                                  <input type="checkbox" name="agency" class="filter" value="{{ $agency }}">
                                  {{ $agency }}
                                  <span class="checkmark"></span>
                              </label>
                          </li>
                      @endforeach
                  </ul>
                @endif
              </div>
              <!-- <div class="tr-filter-lists">
                <h5>Other</h5>
                <ul>
                  <li class="tr-filter-list"><label class="tr-check-box"><input type="checkbox" name="" id=""
                        class="filter" value="Properties without prices">Properties without prices<span
                        class="checkmark"></span></label></li>
                  <li class="tr-filter-list"><label class="tr-check-box"><input type="checkbox" name="" id=""
                        class="filter" value="Properties without photos">Properties without photos<span
                        class="checkmark"></span></label></li>
                </ul>
              </div> -->
            </div>
            @endif
            <!--Filter - END-->
            <!--ROOM - START-->
            <div class="tr-room-section-2 filter-listing responsive-container" >
              @if($pagetype=="withoutdate")
              <div class="tr-title-filter-section">
                <div class="tr-row">
                  <span class="d-none slugdata">{{$slugdata}}</span>
                  <span class="d-none slugid">{{$slgid}}</span>
                  <span class="d-none lname">{{$lname}}</span>
                  <span class="d-none filter-st">{{$st}}</span>
                  <span class="d-none filter-amenity">{{$amenity}}</span>
                  <h1 class="d-none d-md-block">Showing hotels in {{$lname}}</h1>
                  <h1 class="d-block d-sm-block d-md-none">Top hotels</h1>
                  <div class="tr-share-section">
                    <a href="javascript:void(0);" class="tr-share" data-bs-toggle="modal"
                      data-bs-target="#shareModal">Share</a>
                  </div>
                </div>
                <!--
                <div class="tr-row">
                  <p>{{$count_result}} results found</p>
                </div>
                -->
              </div>
              @endif
              @if(!$searchresults->isEmpty())

              <?php $a = 1;?>
              @foreach($searchresults as $searchresult)
              <div class="tr-hotel-deatils" data-id="{{ $searchresult->id }}">
                <div class="tr-hotal-image">
                  <div id="roomSlider{{$a}}" class="carousel slide" data-bs-touch="false" data-bs-interval="false">
                    <!-- Indicators/dots -->
                    <div class="carousel-indicators">
                      <button type="button" data-bs-target="#roomSlider{{$a}}" data-bs-slide-to="0"
                        class="active">1</button>
                      <button type="button" data-bs-target="#roomSlider{{$a}}" data-bs-slide-to="1">2</button>
                      <button type="button" data-bs-target="#roomSlider{{$a}}" data-bs-slide-to="2">3</button>
                    </div>
                    <!-- The slideshow/carousel -->
                    <div class="carousel-inner">
                      <div class="carousel-item active">
                        <img src="https://photo.hotellook.com/image_v2/crop/h{{ $searchresult->hotelid }}_0/520/460.jpg" alt="{{$searchresult->name}}">
                      </div>
                      <div class="carousel-item">
                        <img src="https://photo.hotellook.com/image_v2/crop/h{{ $searchresult->hotelid }}_1/520/460.jpg" alt="{{$searchresult->name}}">
                      </div>
                      <div class="carousel-item">
                        <img src="https://photo.hotellook.com/image_v2/crop/h{{ $searchresult->hotelid }}_2/520/460.jpg" alt="{{$searchresult->name}}">
                      </div>
                    </div>
                    <!-- Left and right controls/icons -->
                    <button class="carousel-control-prev" type="button" data-bs-target="#roomSlider{{$a}}" data-bs-slide="prev"><span class="carousel-control-prev-icon"></span></button>
                    <button class="carousel-control-next" type="button" data-bs-target="#roomSlider{{$a}}" data-bs-slide="next"><span class="carousel-control-next-icon"></span></button>
                  </div>
                  <button class="tr-anchor-btn tr-save">Save</button>
                </div>
                @if($pagetype=="withdate")
                <div class="tr-hotel-deatil">
                  <div class="tr-heading-with-rating">
                    <?php    $ctName = $lname;
                                $cityname = str_replace(' ', '_', $ctName);
                                $CountryName = str_replace(' ', '_', $countryname);
                                $url = $cityname .'-'.$CountryName;
                                $hotel_url = url('hd-'.$searchresult->slugid.'-' .$searchresult->id .'-'.strtolower( str_replace(' ', '_',  str_replace('#', '!',$searchresult->slug."?checkin={$checkin}&checkout={$checkout}") )) );
                          ?>
                    <h2>
                      <a href="{{ $hotel_url }}" target="_blank" title="{{$searchresult->name}}">{{$searchresult->name}}</a>
                    </h2>
                    <div class="tr-rating">
                      @for ($i = 0; $i < 5; $i++)
                        @if($i < $searchresult->stars )
                        <span class="tr-star">
                          <img src="{{asset('public/frontend/hotel-detail/images/icons/star-fill-icon.svg')}}">
                        </span>
                        @endif
                      @endfor
                    </div>
                  </div>
                  @if($searchresult->CityName !="")
                    <div class="tr-hotel-location"> City of {{$searchresult->CityName}}</div>
                  @endif
                  <div class="tr-like-review">
                    @if($searchresult->rating !="" && $searchresult->rating !=0)
                    <?php

                        $rating = (float)$searchresult->rating;
                         $result = round($rating * 10);

                          if ($result > 95) {
                            $ratingtext = 'Superb';
                            $color = '#29857A';
                            $bgcolor = 'rgba(41, 133, 122, 0.11)';

                        } elseif ($result >= 91 && $result <= 95) {
                            $ratingtext = 'Excellent';
                            $color = '#29857A';
                            $bgcolor = 'rgba(41, 133, 122, 0.11)';
                        } elseif ($result >= 81 && $result <= 90) {
                            $ratingtext = 'Great';
                            $color = '#29857A';
                            $bgcolor = 'rgba(41, 133, 122, 0.11)';
                        } elseif ($result >= 71 && $result <= 80) {
                            $ratingtext = 'Good';
                            $color = '#FFE135';
                            $bgcolor = '#fafab2';
                        } elseif ($result >= 61 && $result <= 70) {
                            $ratingtext = 'Okay';
                            $color = '#FFE135';
                            $bgcolor = '#fafab2';
                        } elseif ($result >= 51 && $result <= 60) {
                            $ratingtext = 'Average';
                            $color = '#FFE135';
                            $bgcolor = '#fafab2';
                        } elseif ($result >= 41 && $result <= 50) {
                            $ratingtext = 'Poor';
                            $color = 'red';
                            $bgcolor = '#ff000026';
                        } elseif ($result >= 21 && $result <= 40) {
                            $ratingtext = 'Disappointing';
                            $color = 'red';
                            $bgcolor = '#ff000026';
                        } else {
                            $ratingtext = 'Bad';
                            $color = 'red';
                            $bgcolor = '#ff000026';
                        }

                      ?>
                    <div class="tr-heart">
                      <svg width="12" height="11" viewBox="0 0 12 11" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path fill-rule="evenodd" clip-rule="evenodd"
                          d="M5.99604 2.28959C5.02968 1.20745 3.41823 0.916356 2.20745 1.90727C0.996677 2.89818 0.826217 4.55494 1.77704 5.7269L5.99604 9.63412L10.215 5.7269C11.1659 4.55494 11.0162 2.88776 9.78463 1.90727C8.55304 0.92678 6.96239 1.20745 5.99604 2.28959Z"
                          fill="white" stroke="white" stroke-linecap="round" stroke-linejoin="round"></path>
                      </svg>
                    </div>

                    <div class="tr-ranting-percent">{{$result}}% </div>
                    <div class="tr-vgood" style="color:{{$color}};background: {{$bgcolor}};">{{$ratingtext}}</div>
                    @endif
                    <!-- <div class="tr-vgood">Very Good</div> -->
                  </div>
                  <div class="tr-hotel-facilities">

            <?php
                $amenities = [];
                if ($searchresult->amenity_info != "") {
                    $amenityData = explode(',', $searchresult->amenity_info);
                    foreach ($amenityData as $item) {
                        if (strpos($item, '|') != false) { // Ensure correct format before splitting
                            list($name, $available) = explode('|', $item); // Split into name and availability (0 or 1)
                            $amenities[] = [
                                'name' => trim($name),
                                'available' => (int) trim($available), // Store as associative array, cast available to int
                            ];

                        }
                    }
					$amenities = array_slice($amenities, 0, 5);
                }

             //  return print_r(  $amenities);
                ?>


            @if (!empty($amenities))
                <ul>
                    @foreach ($amenities as $mnt)
                        <li style="">
                            @if($mnt['available'] == 1 && is_string($mnt['name'])) <!-- Only display the image if available and valid name -->
                                <img src="{{ asset('public/frontend/hotel-detail/images/amenities/'.trim($mnt['name']).'.svg') }}" >
                            @else
                                <img src="{{ asset('public/frontend/hotel-detail/images/amenities/wifi.svg') }}" >
                            @endif
                            {{ $mnt['name'] }}</span> <!-- Display the amenity name -->
                        </li>
                    @endforeach
                </ul>
            @endif
                  </div>
                  <div class="tr-more-facilities">
                   @if($searchresult->short_description !="")
					<ul>
						<?php
						$short_description =[];

						$short_description =  explode('^',$searchresult->short_description);
						$b =0;
						?>
						@foreach($short_description as $data)
						@if($b != 0)
						<li>{{$data}} </li>
						@endif
						<?php $b++; ?>
						@endforeach
					</ul>
					<button class="tr-anchor-btn toggle-list">Read More</button>
					@endif
                  </div>
                </div>

                <div class="tr-hotel-price-section">
                  <!--
                  <div class="tr-deal tr-offer-alert">
                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path
                        d="M13.7263 8.9387L8.94634 13.7187C8.82251 13.8427 8.67546 13.941 8.5136 14.0081C8.35173 14.0752 8.17823 14.1097 8.00301 14.1097C7.82779 14.1097 7.65429 14.0752 7.49242 14.0081C7.33056 13.941 7.18351 13.8427 7.05967 13.7187L1.33301 7.9987V1.33203H7.99967L13.7263 7.0587C13.9747 7.30851 14.1141 7.64645 14.1141 7.9987C14.1141 8.35095 13.9747 8.68888 13.7263 8.9387Z"
                        stroke="#222222" stroke-linecap="round" stroke-linejoin="round" />
                      <path d="M4.66699 4.66797H4.67366" stroke="#222222" stroke-linecap="round" stroke-linejoin="round" />
                    </svg>
                    #1 Best value of 400 places to stay
                  </div>
                  -->
                  <div class="tr-hotel-price-lists ls">
                    @if(!empty($hotels->result))
                    @foreach ($hotels->result as $hotel_result)
                    @if($hotel_result->id == $searchresult->hotelid)
                    <?php
                            $allPrices = [];

                            foreach ($hotel_result->rooms as $room) {
                                $price = $room->total;
                                $agencyId = $room->agencyId;
                                $fullurl = $room->fullBookingURL;
                                $options = $room->options;

                                // Use a unique key to prevent duplicate entries
                                $key = $price . '_' . $agencyId;

                                if (!isset($allPrices[$key])) {
                                    $allPrices[$key] = [
                                        'price' => $price,
                                        'fullBookingURL' => $fullurl,
                                        'agencyId' => $agencyId,
                                        'options' => $options,
                                    ];
                                }
                            }

                            // Convert associative array to indexed array
                            $allPricesArray = array_values($allPrices);

                            // Sort the prices in ascending order
                            usort($allPricesArray, function($a, $b) {
                                return $a['price'] - $b['price'];
                            });

                            // Split into top two and the rest
                            $topTwoPrices = array_slice($allPricesArray, 0, 2);
                            $remainingPrices = array_slice($allPricesArray, 2);
                        ?>

                    <!-- Show the two lowest prices -->
                    @foreach ($topTwoPrices as $data)
                    <div class="tr-hotel-price-list">
                      <div class="tr-row">
                        <div class="tr-hotel-facilities">
                          <ul>
                            <?php
                                            $count = 0;
                                            $priorities = ['breakfast', 'freeWifi'];
                                            foreach ($priorities as $priority) {
                                                if (!empty($data['options']->{$priority})) {
                                                    echo "<li>" . ucfirst($priority) . " included</li>";
                                                    $count++;
                                                }
                                            }
                                            foreach ($data['options'] as $key => $value) {
                                                if ($value === true && !in_array($key, $priorities)) {
                                                    echo "<li>" . ucfirst(str_replace('_', ' ', $key)) . " included</li>";
                                                    $count++;
                                                }
                                                if ($count == 2) break;
                                            }
                                        ?>
                          </ul>
                        </div>
                        <div class="tr-site-details">
                          <img src="{{ 'https://pics.avs.io/hl_gates/100/40/' . $data['agencyId'] . '.png' }}"
                            alt="agency logo">
                        </div>
                      </div>
                      <div class="tr-row">
                        <div class="tr-action" @if($count==1 || $count==0) style="margin-top: 18px;" @endif>
                          <a href="{{ $data['fullBookingURL'] }}" class="tr-btn" target="_blank">View deal</a>
                        </div>
                        <div class="tr-hotel-price"><strong>${{ $data['price'] }}</strong></div>
                      </div>
                    </div>
                    @endforeach

                    <!-- Show remaining prices under "More Price" -->
                    @if(count($remainingPrices) > 0)
                    <div class="more-prices-containers" style="display: none;">
                      @foreach ($remainingPrices as $data)
                      <div class="tr-hotel-price-list">
                        <div class="tr-row">
                          <div class="tr-hotel-facilities">
                            <ul>
                              <?php
                                                $count = 0;
                                                $priorities = ['breakfast', 'freeWifi'];
                                                foreach ($priorities as $priority) {
                                                    if (!empty($data['options']->{$priority})) {
                                                        echo "<li>" . ucfirst($priority) . " included</li>";
                                                        $count++;
                                                    }
                                                }
                                                foreach ($data['options'] as $key => $value) {
                                                    if ($value === true && !in_array($key, $priorities)) {
                                                        echo "<li>" . ucfirst(str_replace('_', ' ', $key)) . " included</li>";
                                                        $count++;
                                                    }
                                                    if ($count == 2) break;
                                                }
                                            ?>
                            </ul>
                          </div>
                          <div class="tr-site-details">
                            <img src="{{ 'https://pics.avs.io/hl_gates/100/40/' . $data['agencyId'] . '.png' }}"
                              alt="agency logo">
                          </div>
                        </div>
                        <div class="tr-row">
                          <div class="tr-action" @if($count==1 || $count==0) style="margin-top: 18px;" @endif>
                            <a href="{{ $data['fullBookingURL'] }}" class="tr-btn" target="_blank">View deal</a>
                          </div>
                          <div class="tr-hotel-price"><strong>${{ $data['price'] }}</strong></div>
                        </div>
                      </div>
                      @endforeach
                    </div>
                    <button class="tr-more-prices ls tr-anchor-btn">More price</button>
                    @endif

                    @endif
                    @endforeach
                    @endif
                  </div>
                </div>
                @else
                <div class="tr-hotel-deatil">
                  <div class="tr-heading-with-rating">
                    <h2 class="hotel-name">
                      <a href="{{ url('hd-'.$searchresult->slugid .'-' .$searchresult->id .'-'.strtolower( str_replace(' ', '_',  str_replace('#', '!',$searchresult->slug) )) ) }}"
                        target="_blank" title="{{$searchresult->name}}">{{$searchresult->name}}</a>
                    </h2>
                    <div class="tr-rating">
                      @for ($i = 0; $i < 5; $i++) @if($i < $searchresult->stars )
                        <span class="tr-star"><img
                            src="{{asset('public/frontend/hotel-detail/images/icons/star-fill-icon.svg')}}"></span>

                        @endif
                        @endfor
                    </div>
                  </div>
                  @if($searchresult->CityName !="") <div class="tr-hotel-location"> City of {{$searchresult->CityName}}
                  </div>@endif
                  <div class="tr-like-review">
                  @if($searchresult->rating !="" && $searchresult->rating !=0)
                    <?php

                        $rating = (float)$searchresult->rating;
                         $result = round($rating * 10);

                          if ($result > 95) {
                            $ratingtext = 'Superb';
                            $color = '#29857A';
                            $bgcolor = 'rgba(41, 133, 122, 0.11)';

                        } elseif ($result >= 91 && $result <= 95) {
                            $ratingtext = 'Excellent';
                            $color = '#29857A';
                            $bgcolor = 'rgba(41, 133, 122, 0.11)';
                        } elseif ($result >= 81 && $result <= 90) {
                            $ratingtext = 'Great';
                            $color = '#29857A';
                            $bgcolor = 'rgba(41, 133, 122, 0.11)';
                        } elseif ($result >= 71 && $result <= 80) {
                            $ratingtext = 'Good';
                            $color = '#FFE135';
                            $bgcolor = '#fafab2';
                        } elseif ($result >= 61 && $result <= 70) {
                            $ratingtext = 'Okay';
                            $color = '#FFE135';
                            $bgcolor = '#fafab2';
                        } elseif ($result >= 51 && $result <= 60) {
                            $ratingtext = 'Average';
                            $color = '#FFE135';
                            $bgcolor = '#fafab2';
                        } elseif ($result >= 41 && $result <= 50) {
                            $ratingtext = 'Poor';
                            $color = 'red';
                            $bgcolor = '#ff000026';
                        } elseif ($result >= 21 && $result <= 40) {
                            $ratingtext = 'Disappointing';
                            $color = 'red';
                            $bgcolor = '#ff000026';
                        } else {
                            $ratingtext = 'Bad';
                            $color = 'red';
                            $bgcolor = '#ff000026';
                        }

                      ?>
                    <div class="tr-heart">
                      <svg width="12" height="11" viewBox="0 0 12 11" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path fill-rule="evenodd" clip-rule="evenodd"
                          d="M5.99604 2.28959C5.02968 1.20745 3.41823 0.916356 2.20745 1.90727C0.996677 2.89818 0.826217 4.55494 1.77704 5.7269L5.99604 9.63412L10.215 5.7269C11.1659 4.55494 11.0162 2.88776 9.78463 1.90727C8.55304 0.92678 6.96239 1.20745 5.99604 2.28959Z"
                          fill="white" stroke="white" stroke-linecap="round" stroke-linejoin="round"></path>
                      </svg>
                    </div>

                    <div class="tr-ranting-percent">{{$result}}% </div>
                    <div class="tr-vgood" style="color:{{$color}};background: {{$bgcolor}};">{{$ratingtext}}</div>
                    @endif
                  </div>

                  <div class="accordion d-none d-md-block" id="accordion{{$a}}">
                    <div class="accordion-items">
                      <div class="accordion-item">
                        <button id="headingOverview{{$a}}" class="" type="button" data-bs-toggle="collapse"
                          data-bs-target="#collapseOne{{$a}}" aria-expanded="true"
                          aria-controls="collapseOne{{$a}}">Overview</button>
                      </div>
                      <div class="accordion-item">
                        <button id="headingAmenities{{$a}}" class="" type="button" data-bs-toggle="collapse"
                          data-bs-target="#collapseTwo{{$a}}" aria-expanded="false"
                          aria-controls="collapseTwo{{$a}}">Amenities</button>
                      </div>
                      <div class="accordion-item">
                        <button id="headingThree{{$a}}" class="collapsed" type="button" data-bs-toggle="collapse"
                          data-bs-target="#collapseThree{{$a}}" aria-expanded="false"
                          aria-controls="collapseThree{{$a}}">Review</button>
                      </div>
                    </div>
                    <div class="accordion-items-content">
                      <div id="collapseOne{{$a}}" class="accordion-collapse collapse show"
                        aria-labelledby="headingOverview{{$a}}" data-bs-parent="#accordion{{$a}}">
                        <div class="tr-more-facilities list-content">
                         @if($searchresult->short_description !="")
							<ul>
								<?php
								$short_description =[];

								$short_description =  explode('^',$searchresult->short_description);
								$b =0;
								?>
								@foreach($short_description as $data)
								@if($b != 0)
								<li>{{$data}} </li>
								@endif
								<?php $b++; ?>
								@endforeach
							</ul>
							<button class="tr-anchor-btn toggle-list">Read More</button>
							@endif
                        </div>
                      </div>
                      <div id="collapseTwo{{$a}}" class="accordion-collapse collapse"
                        aria-labelledby="headingAmenities{{$a}}" data-bs-parent="#accordion{{$a}}">
                        <div class="tr-hotel-facilities">
							  <?php
							$amenities = [];
							if ($searchresult->amenity_info != "") {
								$amenityData = explode(',', $searchresult->amenity_info);
								foreach ($amenityData as $item) {
									if (strpos($item, '|') != false) { // Ensure correct format before splitting
										list($name, $available) = explode('|', $item); // Split into name and availability (0 or 1)
										$amenities[] = [
											'name' => trim($name),
											'available' => (int) trim($available), // Store as associative array, cast available to int
										];

									}
								}
								$amenities = array_slice($amenities, 0, 5);
							}


							?>


						@if (!empty($amenities))
							<ul>
								@foreach ($amenities as $mnt)
									<li style="">
										@if($mnt['available'] == 1 && is_string($mnt['name'])) <!-- Only display the image if available and valid name -->
											<img src="{{ asset('public/frontend/hotel-detail/images/amenities/'.trim($mnt['name']).'.svg') }}" >
										@else
											<img src="{{ asset('public/frontend/hotel-detail/images/amenities/wifi.svg') }}" >
										@endif
										<span>{{ $mnt['name'] }}</span> <!-- Display the amenity name -->
									</li>
								@endforeach
							</ul>
						@endif


                        </div>
                      </div>
                      <div id="collapseThree{{$a}}" class="accordion-collapse collapse"
                        aria-labelledby="headingThree{{$a}}" data-bs-parent="#accordion{{$a}}">
                        <!--
                        <div class="tr-like-review">
                          <div class="tr-vgood">Very Good</div> (100 Review)
                        </div>
                        -->
                        <div class="tr-short-decs paragraph-content">
                          <div class="para-content">
                            <p>{{$searchresult->ReviewSummary}}</p>
                          </div>
                          <button type="button" class="tr-anchor-btn toggle-para">Read More</button>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="d-block d-sm-block d-md-none tr-mobile">
                    <div class="tr-more-facilities">
                      <ul>
                        <!-- <li>Upscale</li>
                          <li>smoke-free hotel</li> -->
                        @if($searchresult->distance !="")<li>{{$searchresult->distance}} miles to city </li>@endif
                      </ul>
                    </div>
                    <div class="tr-hotel-facilities mt-3">
						  @if (!empty($amenities))
						<ul>
							@foreach ($amenities as $mnt)
								<li>
									<span>{{ $mnt['name'] }}</span>
								</li>
							@endforeach
						</ul>
					@endif
                    </div>
                  </div>
                  <div class="tr-view-availability">
                   <button class="tr-btn tr-view-availability-btn"><span class="d-none d-md-block">Enter dates for price</span>
                       <span class="d-block d-sm-block d-md-none">View availability</span></button>
                  </div>
                </div>
                @endif

                @if ($loop->last && $count_result > 1)
                @if (!session()->has('frontend_user'))
                <div class="tr-login-for-more-options">
                  <h2>Log in/Sign up to view all listings</h2>
                  <p>Compare prices from 70+ Hotels websites all at one place</p>
                  <div class="tr-row">
                    <a href="{{route('user_login')}}"><button type="button" class="tr-btn h-sign-up">Sign
                        up</button></a>
                  </div>
                </div>
                @endif
                @endif
              </div>
              <?php $a++;?>
              @endforeach
              @else
              <div class="spinner-border" style="margin-left: 500px;margin-top: 100px;" role="status">
                <span class="visually-hidden">Loading...</span>
              </div>
              @endif
            </div>
            <!--ROOM - END-->
          </div>
          <div class="tr-map-and-filter">
            <button data-bs-toggle="modal" data-bs-target="#mapModal" class="map"><svg width="14" height="14"
                viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                <g clip-path="url(#clip0_2464_12970)">
                  <path
                    d="M0.583984 3.4974V12.8307L4.66732 10.4974L9.33398 12.8307L13.4173 10.4974V1.16406L9.33398 3.4974L4.66732 1.16406L0.583984 3.4974Z"
                    stroke="white" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round" />
                  <path d="M4.66602 1.16406V10.4974" stroke="white" stroke-width="1.2" stroke-linecap="round"
                    stroke-linejoin="round" />
                  <path d="M9.33398 3.5V12.8333" stroke="white" stroke-width="1.2" stroke-linecap="round"
                    stroke-linejoin="round" />
                </g>
                <defs>
                  <clipPath id="clip0_2464_12970">
                    <rect width="14" height="14" fill="white" />
                  </clipPath>
                </defs>
              </svg>Map</button>
            <button id="filterModal" class="filter"><svg width="14" height="14" viewBox="0 0 14 14" fill="none"
                xmlns="http://www.w3.org/2000/svg">
                <path d="M12.8327 1.75H1.16602L5.83268 7.26833V11.0833L8.16602 12.25V7.26833L12.8327 1.75Z"
                  stroke="white" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round" />
              </svg>Filter</button>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Map Modal With Filter & Hotel List - Start-->
  <div class="modal" id="mapModal">
    <div class="modal-dialog">
      <div class="modal-content">
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        <div class="modal-body">
          <div class="tr-hotel-info-section">
            <div class="tr-filters-section" data-section="2">
              <h4 class="tr-filter-label">Filter by:</h4>
              <div class="tr-filter-selected-section selected-data" data-section="2"></div>
            </div>
            <div class="tr-room-section-2"></div>
            <div class="tr-map-section">
              <button class="tr-hide-list">Hide Hotel List</button>
              <div class="tr-hotel-on-map">
                <form>
                  <input type="text" class="form-control" id="" placeholder="Search on map" name="" autocomplete="off">
                  <div class="tr-recent-searchs-modal" id="">
                    <div class="tr-enable-location">Around Current Location</div>
                    <h5>Recent searches</h5>
                    <ul>
                      <li>
                        <div class="tr-place-info">
                          <div class="tr-location-icon"></div>
                          <div class="tr-location-info">
                            <div class="tr-hotel-name">London Hotels</div>
                            <div class="tr-hotel-city">England, United Kingdom</div>
                          </div>
                        </div>
                      </li>
                      <li>
                        <div class="tr-place-info">
                          <div class="tr-location-icon"></div>
                          <div class="tr-location-info">
                            <div class="tr-hotel-name">Morocco</div>
                            <div class="tr-hotel-city">North Africa</div>
                          </div>
                        </div>
                      </li>
                    </ul>
                  </div>
                  <button type="button" hidden class="tr-btn">Countinue</button>
                </form>
              </div>
              <button id="onMapFilterModal" class="filter tr-mobile"><svg width="20" height="20" viewBox="0 0 20 20"
                  fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M18.3337 2.5H1.66699L8.33366 10.3833V15.8333L11.667 17.5V10.3833L18.3337 2.5Z" stroke="black"
                    stroke-linecap="round" stroke-linejoin="round" />
                </svg>Filter</button>
                <div id="map"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- Map Modal With Filter & Hotel List - End-->

  <!--FOOTER-->
  @include('footer')

  <div class="overlay" id="overLay"></div>

  <!-- Share Modal -->
  <div class="modal" id="shareModal">
    <div class="modal-dialog">
      <div class="modal-content">
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        <h3>Share this experience</h3>
        <div class="tr-share-infos">
          <div class="tr-hotel-img">
            <img src="{{asset('public/frontend/hotel-detail/images/room-image-1.png')}}" alt="Room Image">
          </div>
          <div class="tr-share-details">
            <span class="tr-hotel-name">Hyatt Regency Houston West</span>
            <span class="tr-rating">4.83</span>
            <span class="tr-bedrooms">
              <span>2 bedrooms</span>
              <span>3 beds</span>
              <span>2 bathrooms</span>
            </span>
          </div>
        </div>
        <div class="tr-share-options">
          <div class="tr-share-option">
            <a href="javascript:void(0);" class="tr-copy">Copy link</a>
          </div>
          <div class="tr-share-option">
            <a href="javascript:void(0);" class="tr-email">Email</a>
          </div>
          <div class="tr-share-option">
            <a href="javascript:void(0);" class="tr-messages">Messages</a>
          </div>
          <div class="tr-share-option">
            <a href="javascript:void(0);" class="tr-whatsapp">Whatsapp</a>
          </div>
          <div class="tr-share-option">
            <a href="javascript:void(0);" class="tr-messenger">Messenger</a>
          </div>
          <div class="tr-share-option">
            <a href="javascript:void(0);" class="tr-facebook">Facebook</a>
          </div>
          <div class="tr-share-option">
            <a href="javascript:void(0);" class="tr-twitter">Twitter</a>
          </div>
          <div class="tr-share-option">
            <a href="javascript:void(0);" class="tr-embed">Embed</a>
          </div>
        </div>
        <div class="tr-alert tr-copy-alert">Link copied</div>
      </div>
    </div>
  </div>
</body>

</html>
<script src="{{asset('public/frontend/hotel-detail/js/jquery.min.js')}}"></script>
<script type="text/javascript" src="{{ asset('/public/frontend/hotel-detail/js/common.js')}} "></script>
<script type="text/javascript" src="{{ asset('/public/frontend/hotel-detail/js/custom.js')}} "></script>
<script src="{{asset('public/js/hotel_list.js')}} "></script>
<script src="{{ asset('/public/js/custom.js')}}"></script>
<script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>

<script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>
<script>
  document.addEventListener("DOMContentLoaded", function() {
    // Initialize the map with a default center and zoom level
    var defaultCenter = [20.5937, 78.9629]; // Default fallback center (India)
    var defaultZoom = 5;

    // Set map center and zoom if search results are available
    var mapCenter = defaultCenter;
    var mapZoom = defaultZoom;
    @if($searchresults->isNotEmpty() && $searchresults->first()->Latitude && $searchresults->first()->longnitude)
      mapCenter = [{{ $searchresults->first()->Latitude }}, {{ $searchresults->first()->longnitude }}];
      mapZoom = 12; // Adjust zoom level as needed
    @endif

    var map = L.map('map', {
      center: mapCenter,
      zoom: mapZoom
    });

    // Add the CARTO Light basemap layer to the map
    var layer = new L.TileLayer('https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png', {
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>',
      subdomains: 'abcd',
      maxZoom: 19
    });
    map.addLayer(layer);

    // Define a Kayak-style marker with price display and arrow at the bottom
    var kayakIconWithArrow = function(price, highlight = false) {
      const bgColor = highlight ? '#ff4d01' : 'white'; // Change background color on highlight
      const size = highlight ? [80, 55] : [70, 50]; // Increase size on highlight
      return L.divIcon({
        className: 'kayak-div-icon',
        html: `
          <div class="marker-wrapper" style="background: ${bgColor}; border-radius: 12px; border: 1px solid #ccc; padding: 10px; width: ${size[0]}px; height: ${size[1] - 15}px; display: flex; align-items: center; justify-content: center; box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.15); position: relative;">
            <div class="price-label" style="font-weight: bold; font-size: 16px; color: #333;">$${price !== null ? price : ''}</div>
            <div class="marker-arrow" style="content: ''; position: absolute; bottom: -10px; left: 50%; transform: translateX(-50%); width: 0; height: 0; border-left: 10px solid transparent; border-right: 10px solid transparent; border-top: 10px solid ${bgColor}; filter: drop-shadow(0px 2px 5px rgba(0, 0, 0, 0.15));"></div>
          </div>
        `,
        iconSize: size,
        popupAnchor: [0, -30],
      });
    };

    // Create an object to store markers
    var markers = {};

    // Iterate over search results and add markers to the map
    @foreach($searchresults as $searchresult)
      @if($searchresult->Latitude && $searchresult->longnitude)

        // Fetch the correct price and data for each hotel
        <?php
          $price = null;
          if (!empty($hotels->result)) {
              foreach ($hotels->result as $hotel_result) {
                  if ($hotel_result->id == $searchresult->hotelid) {
                      if (!empty($hotel_result->rooms) && isset($hotel_result->rooms[0])) {
                          $price = $hotel_result->rooms[0]->total;
                      }
                      break;
                  }
              }
          }
        ?>

        (function() {
          // Use local variables within the function scope to avoid closure issues
          var price = {{ $price !== null ? $price : 'null' }};
          var imageUrl = "https://photo.hotellook.com/image_v2/crop/h{{ $searchresult->hotelid }}_0/520/460.jpg";
          var hotelName = "{{ $searchresult->name }}";
          var city = "{{ $searchresult->CityName }}";
          var rating = "{{ $searchresult->rating }}";
          var stars = parseInt("{{ $searchresult->stars }}");

          // Create the rating stars HTML only if stars value is valid
          var ratingStars = '';
          if (!isNaN(stars) && stars > 0) {
            for (var i = 0; i < stars; i++) {
              ratingStars += '<img src="{{asset('public/frontend/hotel-detail/images/icons/star-fill-icon.svg')}}" style="width: 15px;">';
            }
          }

          // Create popup content with an image, rating, and city
          var popupContent = `
            <div style="text-align: center;">
              <img src="${imageUrl}" alt="${hotelName}" style="width: 100px; height: 80px; object-fit: cover; margin-bottom: 10px;">
              <h3 style="margin: 5px 0;">${hotelName}</h3>
              <p style="margin: 5px 0;">City: ${city}</p>
              <div style="display: flex; justify-content: center; align-items: center;">
                ${ratingStars}
              </div>
              <p style="margin: 5px 0;">Rating: ${rating}/10</p>
              <p style="margin: 5px 0; font-weight: bold;">Price: $${price}</p>
            </div>
          `;

          // Create a marker with the Kayak-style icon and dynamic price label
          var marker = L.marker([{{ $searchresult->Latitude }}, {{ $searchresult->longnitude }}], {
            icon: kayakIconWithArrow(price),
            riseOnHover: true
          }).addTo(map).bindPopup(popupContent);

          // Store the marker in the markers object using the search result ID as the key
          markers["{{ $searchresult->id }}"] = marker;

          // Add mouseover and mouseout events to open/close the popup and highlight marker
          marker.on('mouseover', function() {
            this.setIcon(kayakIconWithArrow(price, true)); // Highlight the marker
            if (!this.isPopupOpen()) {
              this.openPopup(); // Open the popup when hovering over the marker
            }
          });

          marker.on('mouseout', function() {
            this.setIcon(kayakIconWithArrow(price)); // Reset the marker
            if (this.isPopupOpen()) {
              this.closePopup(); // Close the popup when the mouse leaves the marker
            }
          });
        })(); // Immediately invoke the function to create a closure for each marker

      @endif
    @endforeach

    // Add hover functionality to the listing items
    document.querySelectorAll('.tr-hotel-deatils').forEach(function(listingItem) {
      var listingId = listingItem.dataset.id;

      listingItem.addEventListener('mouseover', function() {
        if (markers[listingId]) {
          markers[listingId].setIcon(kayakIconWithArrow(markers[listingId].options.icon.options.html.match(/\$(\d+)/)?.[1], true)); // Highlight marker
          if (!markers[listingId].isPopupOpen()) {
            markers[listingId].openPopup(); // Open the popup when hovering over the list item
          }
        }
      });

      listingItem.addEventListener('mouseout', function() {
        if (markers[listingId]) {
          markers[listingId].setIcon(kayakIconWithArrow(markers[listingId].options.icon.options.html.match(/\$(\d+)/)?.[1])); // Reset marker
          if (markers[listingId].isPopupOpen()) {
            markers[listingId].closePopup(); // Close the popup when the mouse leaves the list item
          }
        }
      });
    });

    // Resize map appropriately
    map.invalidateSize();

    // Handle modal resizing
    $('#mapModal').on('shown.bs.modal', function () {
      map.invalidateSize();
    });

    setTimeout(function() {
      map.invalidateSize();
    }, 500);
  });
</script>
