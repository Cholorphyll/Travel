Landing page

@include('partials.header-nav')